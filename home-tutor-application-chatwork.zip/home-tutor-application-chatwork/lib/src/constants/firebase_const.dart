import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

class FirebaseConst {
  static String id = FirebaseAuth.instance.currentUser!.uid;
  static DatabaseReference reference = FirebaseDatabase.instance.ref("users");
}
