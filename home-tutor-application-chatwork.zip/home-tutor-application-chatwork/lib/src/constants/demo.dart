const String splashText = """
 Watch your favorite teacher  on
 only one platform. you can watch it
 anytime and anywhere.
 """;
