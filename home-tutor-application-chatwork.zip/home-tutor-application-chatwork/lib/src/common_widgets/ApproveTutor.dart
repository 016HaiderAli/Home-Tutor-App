// ignore_for_file: prefer_const_constructors

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/features/controller/services/paymentService.dart';
import 'package:home_tutor_application/src/utils/colors.dart';
import 'package:home_tutor_application/src/utils/show_snack_bar.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:image_picker/image_picker.dart';
import '../features/controller/services/user_services.dart';
import '../features/model/PaymentModel.dart';

class ApproveTutor extends StatefulWidget {
  final String Id;
  final String name;
  final String DisplayPicture;
  final String contentText;

  ApproveTutor(
      {required this.Id,
      required this.name,
      required this.contentText,
      required this.DisplayPicture});

  @override
  State<ApproveTutor> createState() => _ApproveTutorState();
}

class _ApproveTutorState extends State<ApproveTutor> {
  final PaidAmount = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  var Rating;
  @override
  File? selectedImage;

  // String base64Image = "";
  Future<void> chooseImage(type) async {
    // ignore: prefer_typing_uninitialized_variables

    var image;
    if (type == "camera") {
      image = await ImagePicker().pickImage(
        source: ImageSource.camera,
      );
    } else {
      image = await ImagePicker().pickImage(
        source: ImageSource.gallery,
      );
    }
    if (image != null) {
      setState(() {
        selectedImage = File(image.path);

        // base64Image = base64Encode(selectedImage!.readAsBytesSync());
        // won't have any error now
      });
    }
  }

  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.only(bottom: 20.0, left: 30, right: 30),
      width: size.width / 1,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20.0),
        color: Theme.of(context).colorScheme.onPrimary,

        // color: Color(0xFF262626),
      ),
      child: Padding(
        padding: EdgeInsets.all(15.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              // backgroundImage: NetworkImage(ProfilePicture),
              backgroundImage: NetworkImage(widget.DisplayPicture),
              radius: 70.0,
            ),
            SizedBox(
              height: 10.0,
            ),
            Text(
              widget.name == null ? "--" : widget.name,
              style: TextStyle(
                color: Theme.of(context).colorScheme.onPrimaryContainer,
                fontSize: 18.0,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(
              height: 10.0,
            ),
            if (widget.contentText != "")
              Text(
                widget.contentText,
                style: TextStyle(
                    color: Color.fromARGB(255, 255, 255, 255), fontSize: 16.0),
              ),
            SizedBox(
              height: 10.0,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomButton(Icons.star_border, "Rating",
                    Color.fromARGB(255, 255, 255, 255), () {
                  showDialog<String>(
                      context: context,
                      builder: (context) {
                        return Dialog(
                            backgroundColor: Color.fromARGB(0, 255, 255, 255),
                            child: Container(
                                decoration: BoxDecoration(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .primaryContainer,
                                    borderRadius: BorderRadius.circular(20)),
                                height: size.height / 3,
                                width: size.width / 1.1,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      'Ratings',
                                      style: Theme.of(context)
                                          .textTheme
                                          .displayMedium,
                                    ),
                                    SizedBox(
                                      height: size.height / 15,
                                    ),
                                    SizedBox(
                                        width: size.width / 1,
                                        child: Center(
                                          child: RatingBar.builder(
                                            initialRating: 2,
                                            minRating: 1,
                                            direction: Axis.horizontal,
                                            allowHalfRating: true,
                                            itemCount: 5,
                                            itemPadding: EdgeInsets.symmetric(
                                                horizontal: 4.0),
                                            itemBuilder: (context, _) => Icon(
                                              Icons.star,
                                              color: Colors.amber,
                                            ),
                                            onRatingUpdate: (rating) {
                                              print(rating);
                                              setState(() {
                                                Rating = rating;
                                              });
                                            },
                                          ),
                                        )),
                                    SizedBox(
                                      height: size.height / 15,
                                    ),
                                    CustomButton(Icons.done_all_outlined,
                                        "Done", Colors.white, () async {
                                      var flag = await AddRating(Rating);
                                      if (flag == true) {
                                        showSnackBar(context, "Rating Added");
                                        Navigator.pop(context);
                                      } else {
                                        showSnackBar(
                                            context, "Rating Added failed");
                                      }
                                      Navigator.pop(context);
                                    }, size.width / 1.5)
                                  ],
                                )));
                      });
                }, size.width / 3),
                SizedBox(
                  width: 20,
                ),
                CustomButton(Icons.payments_outlined, "Payments",
                    Color.fromARGB(255, 255, 255, 255), () {
                  showDialog<String>(
                      context: context,
                      builder: (context) {
                        return SingleChildScrollView(
                          scrollDirection: Axis.vertical,
                          child: Dialog(
                              backgroundColor: Color.fromARGB(0, 255, 255, 255),
                              child: Container(
                                  decoration: BoxDecoration(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .primaryContainer,
                                      borderRadius: BorderRadius.circular(20)),
                                  height: size.height / 1.2,
                                  width: size.width / 1.1,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        ' Payments',
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodyLarge,
                                      ),
                                      SizedBox(
                                        height: size.height / 15,
                                      ),
                                      Text("Upload Payment ScreenShot"),
                                      InkWell(
                                        onTap: () {
                                          chooseImage("Image From Gallery");
                                        },
                                        child: Container(
                                            width: size.width / 2,
                                            child: selectedImage != null
                                                ? Image.file(
                                                    selectedImage!,
                                                    fit: BoxFit.cover,
                                                  )
                                                : Image.asset(
                                                    "assets/image/payment.jpg")),
                                      ),
                                      SizedBox(
                                        width: size.width / 1.5,
                                        child: TextFormField(
                                          controller: PaidAmount,
                                          validator: (value) {
                                            if (value == null ||
                                                value.isEmpty) {
                                              return 'Please enter Payment Amount';
                                            }
                                            return null;
                                          },
                                          maxLength: 100,
                                          style: TextStyle(
                                            color: Theme.of(context)
                                                .colorScheme
                                                .onPrimaryContainer,
                                          ),
                                          decoration: InputDecoration(
                                              hintText: "Payment Amount",
                                              hintStyle: TextStyle(
                                                  color: Color.fromARGB(
                                                      255, 255, 255, 255)),
                                              focusedBorder:
                                                  UnderlineInputBorder(
                                                      borderSide: BorderSide(
                                                          color: blueButton)),
                                              border: UnderlineInputBorder(
                                                  borderSide: BorderSide(
                                                      strokeAlign: 2))),
                                        ),
                                      ),
                                      SizedBox(
                                        height: size.height / 15,
                                      ),
                                      CustomButton(Icons.done_all_outlined,
                                          "Done", Colors.white, () async {
                                        var flag = await AddPayment();
                                        if (flag == true) {
                                          showSnackBar(
                                              context, "Payment Added");
                                          Navigator.pop(context);
                                        } else {
                                          showSnackBar(
                                              context, "Adding Payment failed");
                                        }
                                        Navigator.pop(context);
                                      }, size.width / 1.5)
                                    ],
                                  ))),
                        );
                      });
                  // await Share.share("com.example.home_tutor_application");
                }, size.width / 3),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget CustomButton(IconData icon, String actionTitle, Color iconColor,
      Function()? onPress, double size) {
    return InkWell(
      onTap: onPress,
      child: Container(
        width: size,
        height: 40,
        decoration: BoxDecoration(
            color: blueButton, borderRadius: BorderRadius.circular(30)),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(
            icon,
            color: iconColor,
          ),
          SizedBox(
            width: 10,
          ),
          Text(
            actionTitle,
            style: TextStyle(
              color: Colors.white,
            ),
          )
        ]),
      ),
    );
  }

  AddPayment() async {
    try {
      var CreationDate = DateTime.now();
      final currentUserData = await UserServices.getManuallData();

      PaymentModel PaymentObj = PaymentModel(
          id: "1", //---ignore this
          ReciverId: widget.Id,
          ReciverName: widget.name,
          SenderName: currentUserData?.name,
          PaidAmount: PaidAmount.text,
          CreationDate: CreationDate.toString());

      bool flag =
          await paymentServices.insert_Payment(PaymentObj, selectedImage);
      return flag;
    } catch (e) {
      print("error is ---${e}");
      return false;
    }
  }

  AddRating(rating) async {
    try {
      bool flag = await UserServices.User_Rating(widget.Id, rating);
      return flag;
    } catch (e) {
      print("error is ---${e}");
      return false;
    }
  }
}
