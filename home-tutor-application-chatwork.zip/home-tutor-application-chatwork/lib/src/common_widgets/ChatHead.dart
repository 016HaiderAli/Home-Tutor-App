import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/features/controller/services/paymentService.dart';
import 'package:home_tutor_application/src/features/screens/chat/ChatDetailPage.dart';
import 'package:home_tutor_application/src/utils/colors.dart';
import 'package:home_tutor_application/src/utils/show_snack_bar.dart';
import 'package:home_tutor_application/src/utils/text_style.dart';

class ChatHead extends StatelessWidget {
  final String ChatId;
  final String Name;
  final String userId;
  final String image;

  ChatHead({
    required this.ChatId,
    required this.userId,
    required this.Name,
    required this.image,
  });

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) {
              return ChatDetailPage(
                reciverId: userId,
                userName: Name,
                DisplayPicture: image,
                Chatid: ChatId,
              );
            },
          ),
        );
      },
      child: Container(
        margin: EdgeInsets.only(bottom: 20.0, left: 30, right: 30),
        width: size.width / 1,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20.0),
          // color: Color.fromARGB(59, 255, 255, 255),
          color: Theme.of(context).colorScheme.onPrimary,
        ),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            children: [
              Container(
                decoration: BoxDecoration(
                    // color: Color.fromARGB(159, 255, 255, 255),
                    ),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          child: Row(
                            children: [
                              CircleAvatar(
                                backgroundColor:
                                    Color.fromARGB(162, 255, 255, 255),
                                backgroundImage: NetworkImage(image),
                                radius: 30,
                              ),
                              SizedBox(width: 10,),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    Name,
                                    style: TextStyle(
                                        fontSize: size.width / 20,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ]),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
