// ignore_for_file: prefer_const_constructors, use_build_context_synchronously

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/common_widgets/popmenu.dart';
import 'package:home_tutor_application/src/features/screens/Paymentlist/paymentslist.dart';
import 'package:home_tutor_application/src/features/screens/Policy/Policy.dart';
import 'package:home_tutor_application/src/features/screens/Profile/viewProfile.dart';
import 'package:home_tutor_application/src/features/screens/changepassword/Changepassword.dart';
import 'package:home_tutor_application/src/features/screens/login/login_page.dart';

import '../features/controller/services/google_auth_service.dart';
import '../features/controller/services/user_services.dart';
import '../features/model/users_model.dart';

import '../utils/logger.dart';

class MyAppBar extends StatefulWidget {
  const MyAppBar({
    Key? key,
  }) : super(key: key);

  @override
  State<MyAppBar> createState() => _MyAppBarState();
}

class _MyAppBarState extends State<MyAppBar> {
  String? name = ''; //
  String? email = ''; //
  String? photo = ''; //
  String defaultImage =
      'https://firebasestorage.googleapis.com/v0/b/tutor-project-f8758.appspot.com/o/ProfilePictures%2Fpng-transparent-businessperson-computer-icons-avatar-avatar-heroes-public-relations-business.png?alt=media&token=fac34488-9d8e-486e-8c81-20b43b537888';

  // String? gname = '';
  // String? gemail = '';
  // String? gphoto = '';
  late Future<Users> Data;
  bool _is_loading = false;
  var data;
  User? user;
  @override
  void initState() {
    super.initState();
    // getGoogleSignInData();
    getData();
  }

  Future<Users?> getData() async {
    data = await UserServices.getManuallData();

    if (data != null) {
      if (mounted) {
        setState(() {
          photo = data.ProfilePicture;
          name = data.name;
          email = data.email;
        });
      }
    }
    return data;
  }

  // Future<User?> getGoogleSignInData() async {
  //   user = FirebaseAuth.instance.currentUser;
  //   if (user != null && data == null) {
  //     if (mounted) {
  //       setState(() {
  //         gname = user!.displayName;
  //         gemail = user!.email;
  //         gphoto = user!.photoURL;
  //       });
  //     }
  //   } else {
  //     logger.wtf("data bhund in dashbaord");
  //     return null;
  //   }
  //   return user;
  // }

  @override
  Widget build(BuildContext context) {
    return AppBar(
      elevation: 0,
      automaticallyImplyLeading: false,
      // backgroundColor: blackComponent,
      backgroundColor: Theme.of(context).colorScheme.primary,
      flexibleSpace: SafeArea(
        child: Container(
          padding: EdgeInsets.only(right: 16),
          child: Row(
            children: <Widget>[
              SizedBox(
                width: 2,
              ),
              CircleAvatar(
                radius: 25,
                backgroundImage: NetworkImage(
                    data == null ? defaultImage : photo.toString()),
              ),
              SizedBox(
                width: 12,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  // ignore: prefer_const_literals_to_create_immutables
                  children: [
                    Text(
                      data == null
                          ? 'loading...'
                          : name.toString().toUpperCase(),
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.white),
                    ),
                    // data==null?
                  ],
                ),
              ),
              PopUpMen(
                icon: Icon(
                  Icons.menu_sharp,
                  color: Colors.white,
                ),
                menuList: [
                  PopupMenuItem(
                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              return PersonalInfo();
                            },
                          ),
                        );
                      },
                      leading: Icon(
                        CupertinoIcons.person,
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                      ),
                      title: Text(
                        "My Profile",
                        style: TextStyle(
                          color:
                              Theme.of(context).colorScheme.onPrimaryContainer,
                        ),
                      ),
                    ),
                  ),
                  PopupMenuDivider(),
                  PopupMenuItem(
                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              return Paymentlist();
                            },
                          ),
                        );
                      },
                      leading: Icon(
                        Icons.payments_outlined,
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                      ),
                      title: Text(
                        "Payments",
                        style: TextStyle(
                          color:
                              Theme.of(context).colorScheme.onPrimaryContainer,
                        ),
                      ),
                    ),
                  ),
                  PopupMenuItem(
                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              return Policy();
                            },
                          ),
                        );
                      },
                      leading: Icon(
                        Icons.policy,
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                      ),
                      title: Text(
                        "Our Policy",
                        style: TextStyle(
                          color:
                              Theme.of(context).colorScheme.onPrimaryContainer,
                        ),
                      ),
                    ),
                  ),
                  PopupMenuItem(
                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              return ChangePassword();
                            },
                          ),
                        );
                      },
                      leading: Icon(
                        Icons.password,
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                      ),
                      title: Text(
                        "Change Password",
                        style: TextStyle(
                          color:
                              Theme.of(context).colorScheme.onPrimaryContainer,
                        ),
                      ),
                    ),
                  ),
                  PopupMenuDivider(),
                  PopupMenuItem(
                    child: ListTile(
                      onTap: () async {
                        // if (user == null) {
                        //   await AuthServices.signOut();
                        //   await Navigator.push(
                        //     context,
                        //     MaterialPageRoute(
                        //       builder: (context) {
                        //         return LoginPage();
                        //       },
                        //     ),
                        //   );
                        // } else {
                        //   await AuthServices.signOut2();
                        //   await Navigator.push(
                        //     context,
                        //     MaterialPageRoute(
                        //       builder: (context) {
                        //         return LoginPage();
                        //       },
                        //     ),
                        //   );
                        // }
                        await AuthServices.signOut();
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              return LoginPage();
                            },
                          ),
                        );
                      },
                      leading: Icon(
                        Icons.logout,
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                      ),
                      title: Text(
                        "Log Out",
                        style: TextStyle(
                          color:
                              Theme.of(context).colorScheme.onPrimaryContainer,
                        ),
                      ),
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
