// ignore_for_file: avoid_unnecessary_containers, prefer_const_constructors

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/features/controller/services/chatServices.dart';
import 'package:home_tutor_application/src/features/controller/services/user_services.dart';
import 'package:home_tutor_application/src/features/controller/services/tutorServices.dart';
import 'package:home_tutor_application/src/features/model/ChatConnectionModel.dart';
import 'package:home_tutor_application/src/features/model/TutorModel.dart';
import 'package:home_tutor_application/src/features/screens/chat/ChatDetailPage.dart';
import 'package:home_tutor_application/src/utils/colors.dart';
import 'package:home_tutor_application/src/utils/show_snack_bar.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:share_plus/share_plus.dart';
import 'package:uuid/uuid.dart';

import '../utils/text_style.dart';

String? Rating;

class feedBox extends StatefulWidget {
  final String ProfilePicture;
  final String name;
  final String contentText;
  final String Phonenumber;
  final String userId;

  const feedBox(
      {required this.name,
      required this.contentText,
      required this.ProfilePicture,
      required this.Phonenumber,
      required this.userId});

  @override
  State<feedBox> createState() => _feedBoxState();
}

class _feedBoxState extends State<feedBox> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.only(bottom: 20.0, left: 30, right: 30),
      width: size.width / 1,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20.0),
        color: Theme.of(context).colorScheme.onPrimary,
      ),
      child: Padding(
        padding: EdgeInsets.all(15.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            InkWell(
              onTap: () async {
                await getUserData();
                // ignore: use_build_context_synchronously
                showDialog<String>(
                    context: context,
                    builder: (context) {
                      return Dialog(
                          backgroundColor: Color.fromARGB(0, 255, 255, 255),
                          child: Container(
                              decoration: BoxDecoration(
                                  color: Theme.of(context)
                                      .colorScheme
                                      .primaryContainer,
                                  borderRadius: BorderRadius.circular(20)),
                              height: size.height / 2,
                              width: size.width / 1.1,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  CircleAvatar(
                                    backgroundImage:
                                        NetworkImage(widget.ProfilePicture),
                                    radius: 70.0,
                                  ),
                                  Rating == ""
                                      ? Container(
                                          child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              // ignore: prefer_const_literals_to_create_immutables
                                              children: [
                                                Text('new Account'),
                                                Icon(
                                                  Icons.star,
                                                  size: 15,
                                                  color: Colors.amber,
                                                )
                                              ]),
                                        )
                                      : Container(
                                          child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Text("${Rating!}.0"),
                                                Icon(
                                                  Icons.star,
                                                  size: 15,
                                                  color: Colors.amber,
                                                )
                                              ]),
                                        ),
                                  Text(
                                    widget.name,
                                    // style: headline1(size.width),
                                    style: Theme.of(context)
                                        .textTheme
                                        .displayLarge,
                                  ),
                                  SizedBox(
                                    height: size.height / 20,
                                  ),
                                  CustomButton(
                                      Icons.done_all, "Approve", Colors.white,
                                      () async {
                                    var flag = await ApproveTutor();
                                    if (flag == true) {
                                      showSnackBar(context, "Tutor Approve");

                                      Navigator.pop(context);
                                    } else {
                                      showSnackBar(context, "Approval Failed");
                                    }
                                  }, size.width / 1.5)
                                ],
                              )));
                    });
              },
              child: CircleAvatar(
                backgroundImage: NetworkImage(widget.ProfilePicture),
                radius: 70.0,
              ),
            ),
            SizedBox(
              height: 10.0,
            ),
            SizedBox(
              height: 10.0,
            ),
            Text(
              widget.name == null ? "--" : widget.name,
              style: Theme.of(context).textTheme.displaySmall,
            ),
            SizedBox(
              height: 10.0,
            ),
            if (widget.contentText != "")
              Text(
                widget.contentText,
                style: Theme.of(context).textTheme.displaySmall,
              ),
            SizedBox(
              height: 10.0,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomButton(Icons.comment, "message",
                    Color.fromARGB(255, 255, 255, 255), () {
                  showDialog<String>(
                      context: context,
                      builder: (context) {
                        return Dialog(
                            backgroundColor: Color.fromARGB(0, 255, 255, 255),
                            child: Container(
                                decoration: BoxDecoration(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .primaryContainer,
                                    borderRadius: BorderRadius.circular(20)),
                                height: size.height / 2,
                                width: size.width / 1.1,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    CircleAvatar(
                                      backgroundImage:
                                          NetworkImage(widget.ProfilePicture),
                                      radius: 70.0,
                                    ),
                                    Text(
                                      widget.name,
                                      style: Theme.of(context)
                                          .textTheme
                                          .displayLarge,
                                    ),
                                    SizedBox(
                                      height: size.height / 20,
                                    ),
                                    CustomButton(
                                        Icons.done_all,
                                        "Connect with Tutor",
                                        Colors.white, () async {
                                      var uuid = Uuid();
                                      var Chatid = uuid.v4();
                                      var flag =
                                          await ConnectingWithTutor(Chatid);
                                      if (flag == true) {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) {
                                              return ChatDetailPage(
                                                reciverId: widget.userId,
                                                userName: widget.name,
                                                DisplayPicture:
                                                    widget.ProfilePicture,
                                                Chatid: Chatid,
                                              );
                                            },
                                          ),
                                        );
                                      } else {
                                        showSnackBar(context,
                                            "Connecting to Tutor Failed");
                                      }
                                    }, size.width / 1.5)
                                  ],
                                )));
                      });
                }, size.width / 3),
                SizedBox(
                  width: 20,
                ),
                CustomButton(
                    Icons.share, "Share", Color.fromARGB(255, 255, 255, 255),
                    () async {
                  await Share.share(
                      "${widget.name}\n\n${widget.contentText}\n\n");
                }, size.width / 3),
              ],
            )
          ],
        ),
      ),
    );
  }

  ConnectingWithTutor(Chatid) async {
    try {
      var CreationDate = DateTime.now();
      var currentUserId = FirebaseAuth.instance.currentUser!.uid;

      ChatConnectiionModel connectionObj = ChatConnectiionModel(
          id: Chatid,
          chatwithUserId: widget.userId,
          chatwithUserName: widget.name,
          chatwithUserProfilePicture: widget.ProfilePicture,
          currentUseridChat: currentUserId,
          CreationDate: CreationDate.toString());

      bool flag = await chatServices.ConnectingWithTutor(connectionObj);
      return flag;
    } catch (e) {
      print("error is ---${e}");
      return false;
    }
  }

  ApproveTutor() async {
    try {
      var CreationDate = DateTime.now();
      var authId = FirebaseAuth.instance.currentUser!.uid;
      if (authId == widget.userId) {
        Navigator.pop(context);
        showSnackBar(context, "You can't Approve Yourself");
      } else {
        TutorModel TutorObj = TutorModel(
            id: '1', //---ignore this id
            DisplayPicture: widget.ProfilePicture,
            TutorName: widget.name,
            TutorId: widget.userId,
            CreationDate: CreationDate.toString());
        bool flag = await tutorServices.insert_Tutor(TutorObj);
        return flag;
      }
    } catch (e) {
      print("error is ---${e}");
      return false;
    }
  }

  getUserData() async {
    try {
      final userData = await UserServices.getUserById(widget.userId);
      Rating = userData?.Rating;
      return true;
    } catch (e) {
      print("error is ---${e}");
      return false;
    }
  }

  Open_WhatsApp(@required Phonenumber) async {
    final Uri _url = Uri.parse('whatsapp://send?phone=$Phonenumber');
    await launchUrl(_url);
  }
//---on click function for whatsapp

  // if (widget.Phonenumber.toString().isEmpty) {
  //   showSnackBar(
  //       context, "This person not enter the phone number");
  //   return null;
  // }
  // Open_WhatsApp(widget.Phonenumber);
}

Widget CustomButton(IconData icon, String actionTitle, Color iconColor,
    Function()? onPress, double size) {
  return InkWell(
    onTap: onPress,
    child: Container(
      width: size,
      height: 40,
      decoration: BoxDecoration(
          color: blueButton, borderRadius: BorderRadius.circular(30)),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(
          icon,
          color: iconColor,
        ),
        Text(
          actionTitle,
          style: TextStyle(
            color: Colors.white,
          ),
        )
      ]),
    ),
  );
}
