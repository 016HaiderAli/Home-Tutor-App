import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/features/controller/services/paymentService.dart';
import 'package:home_tutor_application/src/utils/colors.dart';
import 'package:home_tutor_application/src/utils/show_snack_bar.dart';
import 'package:home_tutor_application/src/utils/text_style.dart';

class paymentBox extends StatelessWidget {
  final String PaymentId;
  final String Name;
  final String PaidAmount;
  final String Status;
  final String image;
  final bool showApproval;
  paymentBox(
      {required this.PaymentId,
      required this.Name,
      required this.PaidAmount,
      required this.image,
      required this.Status,
      required this.showApproval});

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.only(bottom: 20.0, left: 30, right: 30),
      width: size.width / 1,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20.0),
        // color: Color.fromARGB(59, 255, 255, 255),
        color: Theme.of(context).colorScheme.surface,
      ),
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                  // color: Color.fromARGB(159, 255, 255, 255),
                  ),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        child: Row(
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  Name,
                                  style: TextStyle(
                                      fontSize: size.width / 20,
                                      fontWeight: FontWeight.bold),
                                ),
                                Text(
                                  PaidAmount,
                                  style: TextStyle(
                                    fontSize: size.width / 27,
                                  ),
                                ),
                                Text(
                                  Status,
                                  style: TextStyle(
                                    fontSize: size.width / 34,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Container(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            InkWell(
                              onTap: () {
                                showDialog<String>(
                                    context: context,
                                    builder: (context) {
                                      return Dialog(
                                          backgroundColor:
                                              // Color.fromARGB(0, 255, 255, 255),
                                              Theme.of(context)
                                                  .colorScheme
                                                  .surface,
                                          child: Container(
                                              decoration: BoxDecoration(
                                                  color: Theme.of(context)
                                                      .colorScheme
                                                      .surface,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          20)),
                                              // height: size.height / 3,
                                              width: size.width / 1.1,
                                              child: SingleChildScrollView(
                                                child: Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    SizedBox(
                                                      height: size.height / 15,
                                                    ),
                                                    Container(
                                                      height: size.height / 3,
                                                      width: size.width / 1.1,
                                                      child: Image(
                                                          image: NetworkImage(
                                                              image)),
                                                    ),
                                                    SizedBox(
                                                      height: size.height / 15,
                                                    ),
                                                    CustomButton(
                                                        Icons.close,
                                                        "Close",
                                                        Colors.white, () async {
                                                      Navigator.pop(context);
                                                    }, size.width / 1.5)
                                                  ],
                                                ),
                                              )));
                                    });
                              },
                              child: CircleAvatar(
                                backgroundColor:
                                    Color.fromARGB(162, 255, 255, 255),
                                backgroundImage: NetworkImage(image),
                                radius: 30,
                              ),
                            ),
                            showApproval == false
                                ? Text("")
                                : PopupMenuButton(
                                    itemBuilder: (BuildContext context) => [
                                      PopupMenuItem(
                                        child: Text("Approve"),
                                        onTap: () async {
                                          var flag = await PaymentApprove();
                                          if (flag == true) {
                                            showSnackBar(
                                                context, "Payment Approve");
                                            Navigator.pop(context);
                                          } else {
                                            showSnackBar(
                                                context, "Approval Failed");
                                          }
                                        },
                                      ),
                                    ],
                                  )
                          ],
                        ),
                      )
                    ]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  PaymentApprove() async {
    try {
      bool flag = await paymentServices.ApprovePayment(PaymentId);
      return flag;
    } catch (e) {
      print("error is ---${e}");
      return false;
    }
  }

  Widget CustomButton(IconData icon, String actionTitle, Color iconColor,
      Function()? onPress, double size) {
    return InkWell(
      onTap: onPress,
      child: Container(
        width: size,
        height: 40,
        decoration: BoxDecoration(
            color: blueButton, borderRadius: BorderRadius.circular(30)),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(
            icon,
            color: iconColor,
          ),
          SizedBox(
            width: 10,
          ),
          Text(
            actionTitle,
            style: TextStyle(
              color: Colors.white,
            ),
          )
        ]),
      ),
    );
  }
}
