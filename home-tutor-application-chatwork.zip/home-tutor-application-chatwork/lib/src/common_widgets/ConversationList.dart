import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/features/screens/chat/ChatDetailPage.dart';

import '../features/controller/services/user_services.dart';
import '../features/model/users_model.dart';
import '../features/screens/chat/chatpage.dart';
import '../utils/logger.dart';

class ConversationList extends StatefulWidget {
  String name;
  String messageText;
  String imageUrl;
  String time;
  bool isMessageRead;
  ConversationList(
      {required this.name,
      required this.messageText,
      required this.imageUrl,
      required this.time,
      required this.isMessageRead});
  @override
  _ConversationListState createState() => _ConversationListState();
}

class _ConversationListState extends State<ConversationList> {
  String? name = ''; //
  String? email = ''; //
  String? photo = ''; //
  String defaultImage =
      'https://images.unsplash.com/photo-1554151228-14d9def656e4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8OXx8cGVyc29ufGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=800&q=60';

  String? gname = '';
  String? gemail = '';
  String? gphoto = '';
  late Future<Users> Data;
  bool _is_loading = false;
  var data;
  User? user;
  @override
  void initState() {
    super.initState();
    getGoogleSignInData();
    getData();
  }

  Future<Users?> getData() async {
    data = await UserServices.getManuallData();

    if (data != null) {
      if (mounted) {
        setState(() {
          name = data.name;
          email = data.email;
        });
      }
    }
  }

  Future<User?> getGoogleSignInData() async {
    user = FirebaseAuth.instance.currentUser;
    if (user != null && data == null) {
      if (mounted) {
        setState(() {
          gname = user!.displayName;
          gemail = user!.email;
          gphoto = user!.photoURL;
        });
      }
    } else {
      logger.wtf("data bhund in dashbaord");
      return null;
    }
    return user;
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) {
          return chatpage(
            email: data == null ? gemail : gemail,
          );
        }));
      },
      child: Container(
        padding: EdgeInsets.only(left: 16, right: 16, top: 10, bottom: 10),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Row(
                children: <Widget>[
                  CircleAvatar(
                    backgroundImage: NetworkImage(widget.imageUrl),
                    maxRadius: 30,
                  ),
                  SizedBox(
                    width: 16,
                  ),
                  Expanded(
                    child: Container(
                      color: Colors.transparent,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            widget.name,
                            style: TextStyle(fontSize: 16, color: Colors.white),
                          ),
                          SizedBox(
                            height: 6,
                          ),
                          Text(
                            widget.messageText,
                            style: TextStyle(
                                fontSize: 13,
                                color: Color.fromARGB(255, 83, 82, 82),
                                fontWeight: widget.isMessageRead
                                    ? FontWeight.bold
                                    : FontWeight.normal),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Text(
              widget.time,
              style: TextStyle(
                  fontSize: 12,
                  fontWeight: widget.isMessageRead
                      ? FontWeight.bold
                      : FontWeight.normal,
                  color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}
