// ignore_for_file: prefer_const_constructors, use_build_context_synchronously

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/features/controller/services/PostService.dart';
import 'package:home_tutor_application/src/features/screens/Home/homeScreen.dart';
import 'package:home_tutor_application/src/utils/colors.dart';
import 'package:home_tutor_application/src/utils/show_snack_bar.dart';
import 'package:home_tutor_application/src/utils/text_style.dart';

import '../features/model/PostModel.dart';

class myPost extends StatelessWidget {
  final String PostId;
  final String name;
  final String ProfilePicture;
  final String contentText;

  myPost(
      {required this.PostId,
      required this.name,
      required this.contentText,
      required this.ProfilePicture});

  final description = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.only(bottom: 20.0, left: 30, right: 30),
      width: size.width / 1,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20.0),
        color: Theme.of(context).colorScheme.surface,

        // color: Color(0xFF262626),
      ),
      child: Padding(
        padding: EdgeInsets.all(15.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              backgroundImage: NetworkImage(ProfilePicture),
              radius: 70.0,
            ),
            SizedBox(
              height: 10.0,
            ),
            Text(
              name == null ? "--" : name,
              style: TextStyle(
                color: Theme.of(context).colorScheme.onPrimaryContainer,
                fontSize: 18.0,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(
              height: 10.0,
            ),
            if (contentText != "")
              Text(
                contentText,
                style: TextStyle(
                    color: Theme.of(context).colorScheme.onPrimaryContainer,
                    fontSize: 16.0),
              ),
            SizedBox(
              height: 10.0,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomButton(
                    Icons.edit, "Edit Post", Color.fromARGB(255, 255, 255, 255),
                    () {
                  showDialog<String>(
                      context: context,
                      builder: (context) {
                        return Dialog(
                            backgroundColor:
                                Theme.of(context).colorScheme.primaryContainer,
                            child: Container(
                                decoration: BoxDecoration(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .primaryContainer,
                                    borderRadius: BorderRadius.circular(20)),
                                height: size.height / 3,
                                width: size.width / 1.1,
                                child: Form(
                                  key: _formKey,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        'Edit Post',
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodyLarge,
                                      ),
                                      SizedBox(
                                        height: size.height / 15,
                                      ),
                                      SizedBox(
                                        width: size.width / 1.5,
                                        child: TextFormField(
                                          controller: description,
                                          validator: (value) {
                                            if (value == null ||
                                                value.isEmpty) {
                                              return 'Please enter Post Description';
                                            }
                                            return null;
                                          },
                                          maxLength: 100,
                                          style: TextStyle(color: Colors.white),
                                          decoration: InputDecoration(
                                              hintText: "New Description",
                                              hintStyle: Theme.of(context)
                                                  .textTheme
                                                  .bodySmall,
                                              focusedBorder:
                                                  UnderlineInputBorder(
                                                      borderSide: BorderSide(
                                                          color: blueButton)),
                                              border: UnderlineInputBorder(
                                                  borderSide: BorderSide(
                                                      strokeAlign: 2))),
                                        ),
                                      ),
                                      CustomButton(
                                          Icons.save_alt,
                                          "Save Change",
                                          Colors.white, () async {
                                        if (_formKey.currentState!.validate()) {
                                          var flag = await UpdatePost();
                                          if (flag == true) {
                                            showSnackBar(
                                                context, "post updated");
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) {
                                                  return HomeScreen();
                                                },
                                              ),
                                            );
                                          } else {
                                            showSnackBar(
                                                context, "posting Failed");
                                          }
                                        }
                                      }, size.width / 1.5)
                                    ],
                                  ),
                                )));
                      });
                }, size.width / 3),
                SizedBox(
                  width: 20,
                ),
                CustomButton(
                    Icons.delete, "Delete", Color.fromARGB(255, 255, 255, 255),
                    () {
                  showDialog<String>(
                      context: context,
                      builder: (BuildContext context) => CupertinoAlertDialog(
                            title: Text("Deleting Post"),
                            content: Text(
                                "Are you sure you when to delete this post"),
                            actions: [
                              TextButton(
                                  onPressed: () async {
                                    var flag = await DeletePost();
                                    if (flag == true) {
                                      showSnackBar(context, "Post Delete");
                                      Navigator.pop(context);
                                    } else {
                                      showSnackBar(context, "Deleting Failed");
                                    }
                                    Navigator.pop(context);
                                  },
                                  child: Text("Delete")),
                              TextButton(
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                  child: Text("Cancel"))
                            ],
                          ));
                  // await Share.share("com.example.home_tutor_application");
                }, size.width / 3),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget CustomButton(IconData icon, String actionTitle, Color iconColor,
      Function()? onPress, double size) {
    return InkWell(
      onTap: onPress,
      child: Container(
        width: size,
        height: 40,
        decoration: BoxDecoration(
            color: blueButton, borderRadius: BorderRadius.circular(30)),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(
            icon,
            color: iconColor,
          ),
          Text(
            actionTitle,
            style: TextStyle(
              color: Colors.white,
            ),
          )
        ]),
      ),
    );
  }

  DeletePost() async {
    try {
      bool flag = await PostServices.Delete_Post(PostId);
      return flag;
    } catch (e) {
      print("error is ---${e}");
      return false;
    }
  }

  UpdatePost() async {
    try {
      var modificationDate = DateTime.now();

      PostModel PostObj = PostModel(
          id: PostId,
          name: name,
          DisplayPicture: ProfilePicture,
          description: description.text,
          modificationDate: modificationDate.toString());
      bool flag = await PostServices.Update_Post(PostObj);
      return flag;
    } catch (e) {
      print("error is ---${e}");
      return false;
    }
  }
}
