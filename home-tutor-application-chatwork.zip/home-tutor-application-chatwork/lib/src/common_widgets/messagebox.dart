// ignore_for_file: avoid_unnecessary_containers, prefer_const_constructors

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/features/controller/services/user_services.dart';
import 'package:home_tutor_application/src/features/controller/services/tutorServices.dart';
import 'package:home_tutor_application/src/features/model/TutorModel.dart';
import 'package:home_tutor_application/src/features/screens/chat/ChatDetailPage.dart';
import 'package:home_tutor_application/src/utils/colors.dart';
import 'package:home_tutor_application/src/utils/show_snack_bar.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:share_plus/share_plus.dart';

import '../utils/text_style.dart';

String? Rating;

class messegeBox extends StatefulWidget {
  final String name;
  final String contentText;

  const messegeBox({
    required this.name,
    required this.contentText,
  });

  @override
  State<messegeBox> createState() => _messegeBoxState();
}

class _messegeBoxState extends State<messegeBox> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.only(bottom: 20.0, left: 30, right: 30),
      width: size.width / 1,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20.0),
        color: Theme.of(context).colorScheme.onPrimary,
      ),
      child: Padding(
        padding: EdgeInsets.all(15.0),
        child: Row(
          children: [
            Text(
              widget.name + ": ",
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                  width: size.width / 4.7,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(widget.contentText),
                    ],
                  )),
            )
          ],
        ),
      ),
    );
  }
}
