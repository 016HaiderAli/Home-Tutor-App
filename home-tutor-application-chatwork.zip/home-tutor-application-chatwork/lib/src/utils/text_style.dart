import 'package:flutter/material.dart';

import 'colors.dart';

TextStyle headline1(size) => TextStyle(
      fontSize: size / 16,
      color: whiteText,
      fontWeight: FontWeight.bold,
    );

TextStyle headline2(size) => TextStyle(
      fontSize: size / 26,
      color: whiteText,
    );

const TextStyle headline = TextStyle(
  fontSize: 28,
  color: whiteText,
  fontWeight: FontWeight.bold,
);

const TextStyle headlineDot = TextStyle(
  fontSize: 30,
  color: blueText,
  fontWeight: FontWeight.bold,
);

const TextStyle headline3 = TextStyle(
  fontSize: 14,
  color: grayText,
  fontWeight: FontWeight.bold,
);
const TextStyle hintStyle = TextStyle(
  fontSize: 14,
  color: grayText,
  fontWeight: FontWeight.bold,
);
