import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/utils/logger.dart';
import 'package:http/http.dart' as http;

 
  sendNotification(String title) async {
    final data = {
      'click_action': 'FLUTTER_NOTIFICATION_CLICK',
      'id': '1',
      'status': 'done',
      'message': "hey man",
    };

    try {
      http.Response response = await http.post(
        Uri.parse('https://fcm.googleapis.com/fcm/send'),
        headers: <String, String>{
          'Content-Type': 'application/json',
          'Authorization':
              'key=AAAAUJQfhR8:APA91bEEAqv1ZpLLsGWf_tf4fKGw2J1_DEKsxKEYj7UkuqtdRYMFAQ5FxH9s8gnJKXowm7IsQw05PQmacuFflhXdyuOub36Ji2pLOid9VrUSDLbnpyPrVpN-DpCWhSrEjm0h6UJxAVtL'
        },
        body: jsonEncode(
          <String, dynamic>{
            'notification': <String, dynamic>{
              'title': title,
              'body': 'You are followed by someone'
            },
            'priority': 'high',
            'data': data,
            'to': '/topics/subscription'
          },
        ),
      );

      if (response.statusCode == 200) {
        print("Yeh notificatin is sended");
        logger.i("Yeh notificatin is sended");
      } else {
        logger.wtf("error");
        logger.e(response.statusCode);
      }
    } catch (e) {
      logger.e(e);
    }
  }
