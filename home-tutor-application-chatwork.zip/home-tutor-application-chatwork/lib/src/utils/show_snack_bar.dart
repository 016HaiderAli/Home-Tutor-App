import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/utils/colors.dart';

void showSnackBar(BuildContext context, String text) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(text,style: TextStyle(color: white),),
    ),
  );
}
  