import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'firebase_options.dart';
import '../utils/logger.dart';
import 'local_notification.dart';

Future<void> _onBackground_listener(RemoteMessage message) async {}

class FirebaseDB {
  static Future<FirebaseApp?> init() async {
    try {
      WidgetsFlutterBinding.ensureInitialized();
      await Firebase.initializeApp(
        options: DefaultFirebaseOptions.currentPlatform,
      ).then((value) => logger.wtf("FirebaseConnected"));
      LocalNotificationService.initialize();
      FirebaseMessaging.onBackgroundMessage(_onBackground_listener);

      final fcmToken = await FirebaseMessaging.instance.getToken();
      logger.wtf(fcmToken);
    } catch (e) {
      logger.w(e);
    }
  }
}
