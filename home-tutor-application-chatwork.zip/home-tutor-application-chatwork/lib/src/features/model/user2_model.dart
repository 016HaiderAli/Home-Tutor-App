class User2 {
  final String? uid;
  final String? name;
  final String? email;
  final String? password;
  final String? phone;
  final String? rating;
  final String? profilePicture;

  const User2(
      {this.email,
      this.uid,
      this.name,
      this.password,
      this.rating,
      this.phone,
      this.profilePicture});

  Map<String, dynamic> toJson() => {
        "uid": uid,
        "email": email,
        "name": name,
        "rating": rating,
        "password": password,
        "profilePicture": profilePicture,
        "phone": phone
      };

  factory User2.fromJson(dynamic json) {
    return User2(
        uid: json['uid'],
        email: json['email'],
        name: json['name'],
        rating: json['rating'].toString(),
        password: json['password'],
        profilePicture: json['profilePicture'],
        phone: json['phone']);
  }
}
