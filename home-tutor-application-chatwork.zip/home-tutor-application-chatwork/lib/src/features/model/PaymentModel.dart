//----salman
class PaymentModel {
  late String id;
  late String? ReciverId;
  late String? PaymentSenderId;
  late String? SenderName;
  late String? ReciverName;
  late String? PaidAmount;
  late String? paymentImage;
  late String? CreationDate;
  late String? modificationDate;
  late bool? visible;

  PaymentModel(
      {required this.id,
      this.ReciverId,
      this.PaymentSenderId,
      this.SenderName,
      this.ReciverName,
      this.PaidAmount,
      this.paymentImage,
      this.CreationDate,
      this.modificationDate,
      this.visible
      });

  Map<String, dynamic> toJson() => {
        "id": id,
        "ReciverId": ReciverId,
        "PaymentSenderId":PaymentSenderId,
        "SenderName": SenderName,
        "ReciverName": ReciverName,
        "PaidAmount": PaidAmount,
        "paymentImage": paymentImage,
        "CreationDate": CreationDate,
        "modificationDate": modificationDate,
        "visible":visible
      };

  factory PaymentModel.fromJson(dynamic json) {
    return PaymentModel(
        id: json['id'],
        ReciverId: json['ReciverId'],
        PaymentSenderId: json['PaymentSenderId'],
        SenderName: json['SenderName'],
        ReciverName: json['ReciverName'],
        PaidAmount: json['PaidAmount'],
        paymentImage: json['paymentImage'],
        CreationDate: json['CreationDate'],
        modificationDate: json['modificationDate'],
        visible: json['visible'],
        );
  }
}
