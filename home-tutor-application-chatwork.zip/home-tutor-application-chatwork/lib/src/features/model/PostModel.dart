//----salman
class PostModel {
  late String id;
  late String? userId;
  late String? DisplayPicture;
  late String? name;
  late String? Phonenumber;
  late String description;
  late String? CreationDate;
  late String? modificationDate;

  PostModel(
      {required this.id,
      this.userId,
      this.DisplayPicture,
      this.Phonenumber,
      this.name,
      required this.description,
      this.CreationDate,
      this.modificationDate});

  Map<String, dynamic> toJson() => {
        "id": id,
        "userId": userId,
        "DisplayPicture":DisplayPicture,
        "name": name,
        "Phonenumber": Phonenumber,
        "description": description,
        "CreationDate": CreationDate,
        "modificationDate": modificationDate,
      };

  factory PostModel.fromJson(dynamic json) {
    return PostModel(
        id: json['id'],
        userId: json['userId'],
        DisplayPicture: json['DisplayPicture'],
        name: json['name'],
        Phonenumber: json['Phonenumber'],
        description: json['description'],
        CreationDate: json['CreationDate'],
        modificationDate: json['modificationDate']);
  }
}
