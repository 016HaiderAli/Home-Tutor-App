import 'package:flutter/cupertino.dart';

//----salman
class ChatModel {
  late String id;
  late String ChatId;
  late String? ReciverId;
  late String? SenderId;
  late String? SenderName;
  late String? message;
  late int? CreationDate;
  late String? modificationDate;

  ChatModel({
    required this.id,
    required this.ChatId,
    this.ReciverId,
    this.SenderId,
    this.SenderName,
    this.message,
    this.CreationDate,
    this.modificationDate,
  });

  Map<String, dynamic> toJson() => {
        "id": id,
        "ChatId": ChatId,
        "ReciverId": ReciverId,
        "SenderId": SenderId,
        "SenderName": SenderName,
        "message": message,
        "CreationDate": CreationDate,
        "modificationDate": modificationDate,
      };

  factory ChatModel.fromJson(dynamic json) {
    return ChatModel(
      id: json['id'],
      ChatId: json['ChatId'],
      ReciverId: json['ReciverId'],
      SenderId: json['SenderId'],
      SenderName: json['SenderName'],
      message: json['message'],
      CreationDate: json['CreationDate'],
      modificationDate: json['modificationDate'],
    );
  }
}
