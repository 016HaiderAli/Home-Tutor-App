import 'package:flutter/cupertino.dart';

//----salman
class ChatConnectiionModel {
  late String id;
  late String? chatwithUserId;
  late String? chatwithUserProfilePicture;
  late String? chatwithUserName;
  late String? currentUseridChat;

  late String? CreationDate;

  ChatConnectiionModel({
    required this.id,
    this.chatwithUserId,
    this.chatwithUserName,
    this.chatwithUserProfilePicture,
    this.currentUseridChat,
    this.CreationDate,
  });

  Map<String, dynamic> toJson() => {
        "id": id,
        "chatwithUserId": chatwithUserId,
        "chatwithUserName": chatwithUserName,
        "chatwithUserProfilePicture": chatwithUserProfilePicture,
        "currentUseridChat": currentUseridChat,
        "CreationDate": CreationDate,
      };

  factory ChatConnectiionModel.fromJson(dynamic json) {
    return ChatConnectiionModel(
      id: json['id'],
      chatwithUserId: json['chatwithUserId'],
      chatwithUserName: json['chatwithUserName'],
      chatwithUserProfilePicture: json['chatwithUserProfilePicture'],
      currentUseridChat: json['currentUseridChat'],
      CreationDate: json['CreationDate'],
    );
  }
}
