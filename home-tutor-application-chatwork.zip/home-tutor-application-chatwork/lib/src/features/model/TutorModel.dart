//----salman
class TutorModel {
  late String id;
  late String? TutorId;
  late String? TutorName;
  late String? ApproveByUserId;
  late String? DisplayPicture;
  late String? CreationDate;
  late String? modificationDate;

  TutorModel(
      {required this.id,
      this.TutorId,
      this.DisplayPicture,
      this.TutorName,
      this.ApproveByUserId,
      this.CreationDate,
      this.modificationDate});

  Map<String, dynamic> toJson() => {
        "id": id,
        "TutorId": TutorId,
        "DisplayPicture":DisplayPicture,
        "TutorName": TutorName,
        "ApproveByUserId": ApproveByUserId,
        "CreationDate": CreationDate,
        "modificationDate": modificationDate,
      };

  factory TutorModel.fromJson(dynamic json) {
    return TutorModel(
        id: json['id'],
        TutorId: json['TutorId'],
        DisplayPicture: json['DisplayPicture'],
        TutorName: json['TutorName'],
        ApproveByUserId: json['ApproveByUserId'],
        CreationDate: json['CreationDate'],
        modificationDate: json['modificationDate']);
  }
}
