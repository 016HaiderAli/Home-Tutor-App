class Users {
  final String? uid;
  final String name;
  final String? email;
  final String? password;
  final String? phone;
  final String? Rating;
  final String? ProfilePicture;

  const Users(
      {this.email,
      this.uid,
      required this.name,
      this.password,
      this.Rating,
      this.phone,
      this.ProfilePicture});

  Map<String, dynamic> toJson() => {
        "uid": uid,
        "email": email,
        "name": name,
        "Rating": Rating,
        "password": password,
        "ProfilePicture": ProfilePicture,
        "phone": phone
      };

  factory Users.fromJson(dynamic json) {
    return Users(
        uid: json['uid'],
        email: json['email'],
        name: json['name'],
        Rating: json['Rating'].toString(),
        password: json['password'],
        ProfilePicture: json['ProfilePicture'],
        phone: json['phone']);
  }
}
