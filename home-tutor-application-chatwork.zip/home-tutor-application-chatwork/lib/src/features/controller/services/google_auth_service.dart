import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:home_tutor_application/src/features/screens/Home/homeScreen.dart';
import 'package:home_tutor_application/src/features/screens/splashScreen/splashScreen.dart';
import 'package:home_tutor_application/src/features/screens/welcome_screen.dart';
import 'package:home_tutor_application/src/utils/logger.dart';

import '../../model/user2_model.dart';
import '../../model/users_model.dart';

class AuthServices {
//Determine if the user is authenticated.
  static handleAuthState() {
    return StreamBuilder(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (BuildContext context, snapshot) {
          if (snapshot.hasData) {
            return HomeScreen();
          } else {
            return splashScreen();
          }
        });
  }

  static Future<User?> signInWithGoogle() async {
    final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
    try {
      if (googleUser != null) {
        // Obtain the auth details from the request
        final GoogleSignInAuthentication googleAuth =
            await googleUser.authentication;
        logger.wtf(">>> accessToken");
        logger.wtf(googleAuth.accessToken);
        logger.wtf(">>> idToken");
        logger.wtf(googleAuth.idToken);
        if (googleAuth.accessToken != null && googleAuth.idToken != null) {
          final credential = GoogleAuthProvider.credential(
            accessToken: googleAuth.accessToken,
            idToken: googleAuth.idToken,
          );
          final AuthResult =
              await FirebaseAuth.instance.signInWithCredential(credential);
          final user = AuthResult.user;
          return user;
        } else {
          return null;
          // throw PlatformException(
          //   code: 'ERROR_MISSING_GOOGLE_AUTH_TOKEN',
          //   message: 'Missing Google Auth Token',
          // );
        }
      } else {
        logger.wtf("error on googleAuth sevices");
        return null;
      }
    } catch (e) {
      logger.wtf("GoogleAuth err: $e");
    }
  }

//data enter google
  static insert_user(User2 userObj) async {
    try {
      var authId = FirebaseAuth.instance.currentUser!.uid;

      DatabaseReference reference = FirebaseDatabase.instance.ref("users");

      await reference.child(authId).set({
        "uid": userObj.uid,
        "name": userObj.name,
        "email": userObj.email,
        "Rating": userObj.rating,
        "password": userObj.password,
        "phone": userObj.phone,
        "profilePicture": userObj.profilePicture,
      }).then(
        (value) => logger.wtf("data submited"),
      );
      return true;
    } catch (e) {
      logger.wtf("Err on page userservices:$e");
      return false;
    }
  }

  static Future<GoogleSignInAccount?> signOut() async {
    // await FirebaseAuth.instance.signOut();
    await GoogleSignIn().signOut();
    await FirebaseAuth.instance.signOut();
  }

  // static signOut2() async {
  //   await FirebaseAuth.instance.signOut();
  // }
}
