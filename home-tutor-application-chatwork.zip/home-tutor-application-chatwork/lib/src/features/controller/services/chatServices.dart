import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:home_tutor_application/src/features/model/ChatConnectionModel.dart';
import 'package:home_tutor_application/src/features/model/ChatModel.dart';
import 'package:home_tutor_application/src/features/model/PostModel.dart';
import 'package:home_tutor_application/src/features/model/PaymentModel.dart';
import 'package:home_tutor_application/src/utils/logger.dart';
import 'package:uuid/uuid.dart';

class chatServices {
  static SendMessage(ChatModel chatObj) async {
    try {
      var authId = FirebaseAuth.instance.currentUser!.uid;
      DatabaseReference reference =
          FirebaseDatabase.instance.ref("chatMessages");
      var uuid = Uuid();
      var id = uuid.v4();
      await reference.child(id).set({
        "Id": id,
        "SenderId": authId,
        "ChatId": chatObj.ChatId,
        "SenderName": chatObj.SenderName,
        "ReciverId": chatObj.ReciverId,
        "message": chatObj.message,
        "CreateDate": chatObj.CreationDate,
        "visible": true
      }).then(
        (value) => logger.wtf("Data Submited"),
      );

      return true;
    } catch (e) {
      logger.wtf("Err on page userservices:$e");
      return false;
    }
  }

  static ConnectingWithTutor(ChatConnectiionModel connectionObj) async {
    try {
      DatabaseReference reference =
          FirebaseDatabase.instance.ref("ChatConnectiion");
      ;
      await reference.child(connectionObj.id).set({
        "Id": connectionObj.id,
        "currentUseridChat": connectionObj.currentUseridChat,
        "chatwithUserId": connectionObj.chatwithUserId,
        "chatwithUserName": connectionObj.chatwithUserName,
        "chatwithUserProfilePicture": connectionObj.chatwithUserProfilePicture,
        "CreateDate": connectionObj.CreationDate,
        "visible": true
      }).then(
        (value) => logger.wtf("Data Submited"),
      );

      return true;
    } catch (e) {
      logger.wtf("Err on page userservices:$e");
      return false;
    }
  }
}
