import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:home_tutor_application/src/features/model/PostModel.dart';
import 'package:home_tutor_application/src/features/model/PaymentModel.dart';
import 'package:home_tutor_application/src/utils/logger.dart';
import 'package:uuid/uuid.dart';

class paymentServices {
  static insert_Payment(PaymentModel paymentObj, File? image) async {
    var pathimage = image.toString();
    var temp = pathimage.lastIndexOf('/');
    var result = pathimage.substring(temp + 1);
    var userId = FirebaseAuth.instance.currentUser!.uid;
    print(result);
    final ref = FirebaseStorage.instance.ref().child('payments').child(result);
    var response = await ref.putFile(image!);
    print("Updated $response");
    var imageUrl = await ref.getDownloadURL();
    try {
      var authId = FirebaseAuth.instance.currentUser!.uid;
      DatabaseReference reference = FirebaseDatabase.instance.ref("Payments");
      var uuid = Uuid();
      var id = uuid.v4();
      await reference.child(id).set({
        "Id": id,
        "PaymentSenderId": authId,
        "SenderName": paymentObj.SenderName,
        "ReciverName": paymentObj.ReciverName,
        "ReciverId": paymentObj.ReciverId,
        "paymentImage": imageUrl,
        "PaidAmount": paymentObj.PaidAmount,
        "paymentStatus": 'pending',
        "CreateDate": paymentObj.CreationDate,
        "visible": true
      }).then(
        (value) => logger.wtf("Data Submited"),
      );

      return true;
    } catch (e) {
      logger.wtf("Err on page userservices:$e");
      return false;
    }
  }

 
  static ApprovePayment(id) async {
    try {
      var response = await FirebaseDatabase.instance
          .ref('Payments')
          .child(id)
          .update({"paymentStatus": 'Approve'}).then(
        (value) => logger.wtf("Delete record"),
      );
      // ref.child("users").set(userObj.phone);
      return true;
    } catch (e) {
      logger.wtf("Err on page userservices:$e");
      return false;
    }
  }
}
