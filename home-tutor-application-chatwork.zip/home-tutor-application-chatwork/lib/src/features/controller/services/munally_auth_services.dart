import 'package:firebase_auth/firebase_auth.dart';
import 'package:home_tutor_application/src/utils/logger.dart';

class MunallyAuth {
  static Future<UserCredential?> SignUp(
      String userEmail, String userPassword) async {
    try {
      UserCredential userCredential =
          await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: userEmail,
        password: userPassword,
      );
      return userCredential;
    } on FirebaseAuthException catch (e) {
      if (e.code == 'weak-password') {
        logger.wtf('The password provided is too weak.');
        return null;
      } else if (e.code == 'email-already-in-use') {
        logger.wtf('The account already exists for that email.');
        return null;
      }
    } catch (e) {
      logger.wtf('munall auth services page:$e');
    }
  }

  static Future<UserCredential?> Signin(
      String userEmail, String userPassword) async {
    try {
      UserCredential userCredential = await FirebaseAuth.instance
          .signInWithEmailAndPassword(email: userEmail, password: userPassword);
      return userCredential;
      //     .then((response) async {
      //   if (!FirebaseAuth.instance.currentUser!.emailVerified) {
      //     //IF CURTRENT USER NOT VERIFIED
      //     await response.user?.sendEmailVerification();
      //   }
      //   return response;
      // });
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        logger.wtf('No user found for that email.');

        return null;
      } else if (e.code == 'wrong-password') {
        logger.wtf('Wrong password provided for that user.');
        return null;
      }
    }
  }
}
