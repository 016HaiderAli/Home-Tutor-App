import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:home_tutor_application/src/features/model/PostModel.dart';
import 'package:home_tutor_application/src/features/model/TutorModel.dart';
import 'package:home_tutor_application/src/utils/logger.dart';
import 'package:uuid/uuid.dart';

class tutorServices {
  static insert_Tutor(TutorModel TutorObj) async {
    try {
      //   // String authId = FirebaseConst.id;
      var authId = FirebaseAuth.instance.currentUser!.uid;
      //   // DatabaseReference ref = FirebaseConst.reference;
      DatabaseReference reference = FirebaseDatabase.instance.ref("Tutors");
      var uuid = Uuid();
      var id = uuid.v4();
      await reference.child(id).set({
        "Id": id,
        "ApproveByUserId": authId,
        "DisplayPicture": TutorObj.DisplayPicture,
        "TutorName": TutorObj.TutorName,
        "TutorId": TutorObj.TutorId,
        "CreateDate": TutorObj.CreationDate,
        "visible": true
      }).then(
        (value) => logger.wtf("Data Submited"),
      );
      // ref.child("users").set(userObj.phone);
      return true;
    } catch (e) {
      logger.wtf("Err on page userservices:$e");
      return false;
    }
  }

  static Future<PostModel?> GetPostDataById(PostId) async {
    final ref = FirebaseDatabase.instance.ref();
    var Postobj;

    Object? data;
    final snapshot = await ref.child('Posts/$PostId').get();
    if (snapshot.exists) {
      data = snapshot.value;
      Postobj = PostModel.fromJson(data);
    } else {
      logger.wtf('No data available.');
    }
    return Postobj;
  }

  static Update_Post(PostModel PostObj) async {
    try {
      var userId = FirebaseAuth.instance.currentUser!.uid;
      // DatabaseReference reference = FirebaseDatabase.instance.ref("Posts");

      var response = await FirebaseDatabase.instance
          .ref('Posts')
          .child(PostObj.id)
          .update({
        "userId": userId,
        "name": PostObj.name,
        "DisplayPicture": PostObj.DisplayPicture,
        "description": PostObj.description,
        "CreateDate": PostObj.CreationDate
      }).then(
        (value) => logger.wtf("Data Updated"),
      );
      // ref.child("users").set(userObj.phone);
      return true;
    } catch (e) {
      logger.wtf("Err on page userservices:$e");
      return false;
    }
  }

  static Delete_Post(id) async {
    try {
      var response = await FirebaseDatabase.instance
          .ref('Posts')
          .child(id)
          .update({"visible": false}).then(
        (value) => logger.wtf("Delete record"),
      );
      // ref.child("users").set(userObj.phone);
      return true;
    } catch (e) {
      logger.wtf("Err on page userservices:$e");
      return false;
    }
  }
}
