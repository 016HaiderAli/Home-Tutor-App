import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import '../../../utils/logger.dart';
import '../../model/users_model.dart';

class UserServices {
  static insert_user(Users userObj) async {
    try {
      var authId = FirebaseAuth.instance.currentUser!.uid;

      DatabaseReference reference = FirebaseDatabase.instance.ref("users");

      await reference.child(authId).set({
        "uid": authId,
        "name": userObj.name,
        "email": userObj.email,
        "Rating": 0,
        "password": userObj.password,
        "phone": userObj.phone,
        "ProfilePicture":
            "https://firebasestorage.googleapis.com/v0/b/tutor-project-f8758.appspot.com/o/ProfilePictures%2Fpng-transparent-businessperson-computer-icons-avatar-avatar-heroes-public-relations-business.png?alt=media&token=fac34488-9d8e-486e-8c81-20b43b537888"
      }).then(
        (value) => logger.wtf("Data Submited"),
      );

      // ref.child("users").set(userObj.phone);
      return true;
    } catch (e) {
      logger.wtf("Err on page userservices:$e");
      return false;
    }
  }

  static Future<Users?> getManuallData() async {
    final ref = FirebaseDatabase.instance.ref();
    var userobj;
    var userId = FirebaseAuth.instance.currentUser!.uid;
    Object? data;
    final snapshot = await ref.child('users/$userId').get();
    if (snapshot.exists) {
      data = snapshot.value;
      userobj = Users.fromJson(data);

      // logger.wtf(userobj);
    } else {
      logger.wtf('No data available.');
    }
    return userobj;
  }

  static Future<Users?> getUserById(userId) async {
    final ref = FirebaseDatabase.instance.ref();
    var userobj;

    Object? data;
    final snapshot = await ref.child('users/$userId').get();
    if (snapshot.exists) {
      data = snapshot.value;
      userobj = Users.fromJson(data);

      // logger.wtf(userobj);
    } else {
      logger.wtf('No data available.');
    }
    return userobj;
  }

  UpdateUser(Users Userdata, File? image) async {
    var pathimage = image.toString();
    var temp = pathimage.lastIndexOf('/');
    var result = pathimage.substring(temp + 1);
    var userId = FirebaseAuth.instance.currentUser!.uid;
    print(result);
    final ref =
        FirebaseStorage.instance.ref().child('ProfilePictures').child(result);
    var response = await ref.putFile(image!);
    print("Updated $response");
    var imageUrl = await ref.getDownloadURL();
    try {
      var response =
          await FirebaseDatabase.instance.ref('users').child(userId).update({
        "name": Userdata.name,
        // "email": Userdata.email,
        // "password": Userdata.password,
        "phone": Userdata.phone,
        "ProfilePicture": imageUrl
      });
      return true;
    } catch (exception) {
      print("Error Saving Data at firestore $exception");
      return false;
    }
  }

  static User_Rating(id, rating) async {
    try {
      var response = await FirebaseDatabase.instance
          .ref('users')
          .child(id)
          .update({"Rating": rating}).then(
        (value) => logger.wtf("rating added"),
      );

      // ref.child("users").set(userObj.phone);
      return true;
    } catch (e) {
      logger.wtf("Err on page userservices:$e");
      return false;
    }
  }

   ChangePassword(Users usersobj) async {
    try {
      var userId = FirebaseAuth.instance.currentUser!.uid;
      var response = await FirebaseDatabase.instance
          .ref('users')
          .child(userId)
          .update({"password": usersobj.password}).then(
        (value) => logger.wtf("password Updated"),
      );

      return true;
    } catch (e) {
      logger.wtf("Err on page userservices:$e");
      return false;
    }
  }
}
