// ignore_for_file: prefer_const_constructors, use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/common_widgets/MyAppbar.dart';
import 'package:home_tutor_application/src/common_widgets/main_button.dart';
import 'package:home_tutor_application/src/features/controller/services/user_services.dart';
import 'package:home_tutor_application/src/features/model/users_model.dart';
import 'package:home_tutor_application/src/features/screens/Home/homeScreen.dart';
import 'package:home_tutor_application/src/utils/colors.dart';
import 'package:home_tutor_application/src/utils/show_snack_bar.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';

class editProfile extends StatefulWidget {
  final String? userName;
  final String? Phonenumber;
  editProfile(
      {required this.userName, required this.Phonenumber, String? Name});

  @override
  State<editProfile> createState() => _editProfileState();
}

var size, height, width;

class _editProfileState extends State<editProfile> {
  final _formKey = GlobalKey<FormState>();
  final Name = TextEditingController();
  final Password = TextEditingController();
  final Phonenumber = TextEditingController();
  final Email = TextEditingController();

  File? selectedImage;
  // String base64Image = "";

  Future<void> chooseImage(type) async {
    // ignore: prefer_typing_uninitialized_variables

    var image;
    if (type == "camera") {
      image = await ImagePicker().pickImage(
        source: ImageSource.camera,
      );
    } else {
      image = await ImagePicker().pickImage(
        source: ImageSource.gallery,
      );
    }
    if (image != null) {
      setState(() {
        selectedImage = File(image.path);

        // base64Image = base64Encode(selectedImage!.readAsBytesSync());
        // won't have any error now
      });
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Name.text = widget.userName.toString();
    Phonenumber.text = widget.Phonenumber.toString();
  }

  Widget build(BuildContext context) {
    var screensize = MediaQuery.of(context).size;
    size = MediaQuery.of(context).size;
    height = size.height;
    width = size.width;
    return Scaffold(
      // backgroundColor: blackBG,
      appBar: PreferredSize(
        preferredSize: Size(screensize.width, 70),
        child: MyAppBar(),
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(
          children: [
            Container(
              color: Color.fromARGB(0, 215, 236, 246),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(children: [
                  InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Icon(
                      Icons.arrow_back,
                      color: Theme.of(context).colorScheme.onPrimaryContainer,
                      size: screensize.width / 13,
                    ),
                  ),
                  Text(
                    "Edit Profile",
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ]),
              ),
            ),
            Container(
              padding: EdgeInsets.only(top: 30, left: 30),
              child: Row(children: [
                InkWell(
                  onTap: () {
                    chooseImage("Image From Gallery");
                  },
                  child: CircleAvatar(
                    radius: 80,
                    backgroundColor: Color.fromARGB(172, 235, 162, 4),
                    child: Padding(
                      padding: const EdgeInsets.all(8), // Border radius
                      child: ClipOval(
                          child: selectedImage != null
                              ? Image.file(
                                  selectedImage!,
                                  fit: BoxFit.cover,
                                  height: 220,
                                  width: 150,
                                )
                              : Image.network(
                                  'https://firebasestorage.googleapis.com/v0/b/tutor-project-f8758.appspot.com/o/ProfilePictures%2FUpload-Transparent.png?alt=media&token=7738473e-8557-4e17-9831-297f8ab596cd',
                                  fit: BoxFit.cover,
                                  height: 220,
                                  width: 150,
                                )),
                    ),
                  ),
                )
              ]),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 40),
              child: Form(
                key: _formKey,
                child: Column(
                  children: [
                    Container(
                      width: screensize.width / 1.1,
                      height: 70,
                      decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.onPrimary,
                          borderRadius: BorderRadius.circular(15)),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter Name';
                            }
                            return null;
                          },
                          cursorColor:
                              Theme.of(context).colorScheme.onPrimaryContainer,
                          style: TextStyle(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onPrimaryContainer,
                              fontSize: 18),
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintStyle: TextStyle(
                                color: Color.fromARGB(46, 255, 255, 255),
                                fontSize: 20),
                            hintText: 'Name',
                          ),
                          controller: Name,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      width: screensize.width / 1.1,
                      height: 70,
                      decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.onPrimary,
                          borderRadius: BorderRadius.circular(15)),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter PhoneNumber';
                            }
                            return null;
                          },
                          cursorColor:
                              Theme.of(context).colorScheme.onPrimaryContainer,
                          // keyboardType: TextInputType.number,
                          style: TextStyle(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onPrimaryContainer,
                              fontSize: 18),
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintStyle: TextStyle(
                                color: Color.fromARGB(46, 255, 255, 255),
                                fontSize: 20),
                            hintText: '+92xxxxxxxxxx',
                          ),
                          controller: Phonenumber,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: size.height / 5,
                    ),
                    Mainbutton(
                        onTap: () async {
                          if (_formKey.currentState!.validate()) {
                            if (selectedImage != null) {
                              UpdateUser();
                            } else {
                              showSnackBar(
                                  context, "Please select display Pciture");
                            }
                          }
                        },
                        text: "Save Changes",
                        btnColor: blueButton),
                    SizedBox(
                      height: 20,
                    ),
                    SizedBox(
                      height: screensize.height / 24,
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  UpdateUser() async {
    final Svc = UserServices();
    Users UserData = Users(
        // email: Email.text,
        name: Name.text,
        // password: Password.text,
        phone: Phonenumber.text);
    var flag = await Svc.UpdateUser(UserData, selectedImage);

    if (flag == true) {
      showSnackBar(context, "Profile Edit successful");

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) {
            return HomeScreen();
          },
        ),
      );
    } else {
      showSnackBar(context, "Profile Edit Failed");
    }
  }
}
