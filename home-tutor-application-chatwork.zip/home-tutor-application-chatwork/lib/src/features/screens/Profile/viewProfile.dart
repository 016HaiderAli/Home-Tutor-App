// ignore_for_file: prefer_const_constructors

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:home_tutor_application/main.dart';
import 'package:home_tutor_application/src/common_widgets/MyAppbar.dart';
import 'package:home_tutor_application/src/common_widgets/main_button.dart';
import 'package:home_tutor_application/src/features/controller/services/user_services.dart';
import 'package:home_tutor_application/src/features/model/users_model.dart';
import 'package:home_tutor_application/src/features/screens/Profile/editProfile.dart';
import 'package:home_tutor_application/src/utils/colors.dart';
import 'package:home_tutor_application/src/utils/logger.dart';

import '../../../utils/text_style.dart';

var size, height, width;

class PersonalInfo extends StatefulWidget {
  const PersonalInfo({super.key});

  @override
  State<PersonalInfo> createState() => _PersonalInfoState();
}

class _PersonalInfoState extends State<PersonalInfo> {
  String? name = ''; //
  String? email = ''; //
  String? photo = '';
  String? PhoneNumber = ''; //
  String defaultImage =
      'https://images.unsplash.com/photo-1554151228-14d9def656e4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8OXx8cGVyc29ufGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=800&q=60';

  String? gname = '';
  String? gemail = '';
  String? gphoto = '';
  // late Future<Users> Data;
  bool _is_loading = false;
  var data;
  User? user;
  @override
  void initState() {
    super.initState();
    getGoogleSignInData();
    getData();
  }

  Future<Users?> getData() async {
    data = await UserServices.getManuallData();

    if (data != null) {
      if (mounted) {
        setState(() {
          name = data.name;
          email = data.email;
          PhoneNumber = data.phone;
          photo = data.ProfilePicture;
        });
      }
    }
  }

  Future<User?> getGoogleSignInData() async {
    user = FirebaseAuth.instance.currentUser;
    if (user != null && data == null) {
      if (mounted) {
        setState(() {
          gname = user!.displayName;
          gemail = user!.email;
          gphoto = user!.photoURL;
        });
      }
    } else {
      logger.wtf("data bhund in dashbaord");
      return null;
    }
    return user;
  }

  @override
  Widget build(BuildContext context) {
    var screensize = MediaQuery.of(context).size;
    size = MediaQuery.of(context).size;
    height = size.height;
    width = size.width;
    return Scaffold(
      // backgroundColor: blackBG,
      appBar: PreferredSize(
        preferredSize: Size(screensize.width, 70),
        child: MyAppBar(),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      color: Color.fromARGB(0, 255, 255, 255),
                      child: Row(children: [
                        InkWell(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: Icon(
                            Icons.arrow_back,
                            color: Theme.of(context)
                                .colorScheme
                                .onPrimaryContainer,
                            size: screensize.width / 13,
                          ),
                        ),
                        Text(
                          "Personal Information",
                          style: TextStyle(
                            fontSize: screensize.width / 27,
                            fontWeight: FontWeight.bold,
                            color: Theme.of(context)
                                .colorScheme
                                .onPrimaryContainer,
                          ),
                        ),
                      ]),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    CircleAvatar(
                      backgroundImage: NetworkImage(
                          data == null ? gphoto.toString() : photo.toString()),
                      radius: 50,
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Text(
                      "Name",
                      style: TextStyle(
                        color: Colors.grey,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Text(
                      data == null
                          ? gname.toString().toUpperCase()
                          : name.toString().toUpperCase(),
                      style: Theme.of(context).textTheme.displaySmall,
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Container(
                      width: double.infinity,
                      height: 50,
                      color: Theme.of(context).colorScheme.secondary,
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          // ignore: prefer_const_literals_to_create_immutables
                          children: [
                            Text(
                              "Contact Information",
                              style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  color: Colors.white),
                            ),
                          ]),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Text(
                      "Phone Number",
                      style: TextStyle(
                        color: Colors.grey,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Text(
                      data == null
                          ? "loading.."
                          : PhoneNumber.toString().toUpperCase(),
                      style: Theme.of(context).textTheme.displaySmall,
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Text(
                      "Email",
                      style: TextStyle(
                        color: Colors.grey,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      data == null
                          ? gemail.toString().toUpperCase()
                          : email.toString().toUpperCase(),
                      style: Theme.of(context).textTheme.displaySmall,
                    ),
                    SizedBox(
                      height: size.height / 3.5,
                    ),
                    Mainbutton(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) {
                                return editProfile(
                                  Phonenumber: PhoneNumber.toString(),
                                  userName: name,
                                );
                              },
                            ),
                          );
                        },
                        text: 'Edit Profile',
                        btnColor: blueButton),
                    SizedBox(
                      height: 15,
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
