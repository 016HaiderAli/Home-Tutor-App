// ignore_for_file: prefer_const_constructors, use_build_context_synchronously
import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/common_widgets/MyAppbar.dart';
import 'package:home_tutor_application/src/common_widgets/main_button.dart';
import 'package:home_tutor_application/src/features/screens/Adslisting/Approvetutorlist.dart';
import 'package:home_tutor_application/src/features/screens/Adslisting/MyAdslist.dart';
import 'package:home_tutor_application/src/utils/colors.dart';
import 'package:lottie/lottie.dart';

var size, height, width;

class Dashboard extends StatefulWidget {
  const Dashboard({Key? key}) : super(key: key);

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  @override
  Widget build(BuildContext context) {
    var screensize = MediaQuery.of(context).size;
    size = MediaQuery.of(context).size;
    height = size.height;
    width = size.width;
    return Scaffold(
      // backgroundColor: blackBG,
      appBar: PreferredSize(
        preferredSize: Size(screensize.width, 70),
        child: MyAppBar(),
      ),
      body: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
        Expanded(
          child: Lottie.network(
              "https://assets1.lottiefiles.com/packages/lf20_ggt4iszh.json"),
        ),
        Mainbutton(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) {
                  return ApproveTutorlist();
                },
              ),
            );
          },
          text: 'View Approved Tutors',
          btnColor: blueButton,
          icon: Icons.remove_red_eye,
        ),
        SizedBox(
          height: 20,
        ),
        Mainbutton(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) {
                  return MyAdslist();
                },
              ),
            );
          },
          text: ' My Post',
          btnColor: blueButton,
        ),
        SizedBox(
          height: 30,
        )
      ]),
    );
  }
}
