// ignore_for_file: prefer_const_constructors, library_private_types_in_public_api, use_build_context_synchronously, non_constant_identifier_names

import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/features/controller/services/user_services.dart';
import 'package:home_tutor_application/src/features/model/users_model.dart';
import 'package:home_tutor_application/src/features/screens/Home/homeScreen.dart';
import 'package:home_tutor_application/src/utils/logger.dart';
import 'package:home_tutor_application/src/utils/show_snack_bar.dart';
import '../../../common_widgets/main_button.dart';
import '../../../utils/colors.dart';
import '../../../utils/space.dart';
import '../../../utils/text_style.dart';
import '../../controller/services/munally_auth_services.dart';

final _formKey = GlobalKey<FormState>();

class SignUpPage extends StatefulWidget {
  const SignUpPage({Key? key}) : super(key: key);

  @override
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  TextEditingController userEmail = TextEditingController();
  TextEditingController userName = TextEditingController();
  TextEditingController userPass = TextEditingController();
  TextEditingController confirmPass = TextEditingController();
  TextEditingController userPh = TextEditingController();
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      // backgroundColor: blackBG,
      body: Padding(
        padding: EdgeInsets.only(top: 50.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SpaceVH(height: 50.0),
              Text(
                'Create new account',
                style: Theme.of(context).textTheme.displayMedium,
              ),
              SpaceVH(height: 10.0),
              Text(
                'Please fill in the form to continue',
                style: headline3,
              ),
              SpaceVH(height: 60.0),
              Form(
                key: _formKey,
                child: Column(
                  children: [
                    Container(
                      width: size.width / 1.1,
                      height: 70,
                      decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.onPrimary,
                          borderRadius: BorderRadius.circular(15)),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          cursorColor:
                              Theme.of(context).colorScheme.onPrimaryContainer,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter Name';
                            }
                            return null;
                          },
                          style: Theme.of(context).textTheme.displaySmall,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintStyle: Theme.of(context).textTheme.displaySmall,
                            hintText: 'Name',
                          ),
                          controller: userName,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      width: size.width / 1.1,
                      height: 70,
                      decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.onPrimary,
                          borderRadius: BorderRadius.circular(15)),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          cursorColor:
                              Theme.of(context).colorScheme.onPrimaryContainer,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter Email';
                            }
                            return null;
                          },
                          style: Theme.of(context).textTheme.displaySmall,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintStyle: Theme.of(context).textTheme.displaySmall,
                            hintText: 'Email',
                          ),
                          controller: userEmail,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      width: size.width / 1.1,
                      height: 70,
                      decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.onPrimary,
                          borderRadius: BorderRadius.circular(15)),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          cursorColor:
                              Theme.of(context).colorScheme.onPrimaryContainer,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter Phone number';
                            }
                            return null;
                          },
                          style: Theme.of(context).textTheme.displaySmall,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintStyle: Theme.of(context).textTheme.displaySmall,
                            hintText: 'Phone',
                          ),
                          keyboardType: TextInputType.phone,
                          controller: userPh,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      width: size.width / 1.1,
                      height: 70,
                      decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.onPrimary,
                          borderRadius: BorderRadius.circular(15)),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          obscureText: true,
                          enableSuggestions: false,
                          cursorColor:
                              Theme.of(context).colorScheme.onPrimaryContainer,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter Password';
                            }
                            return null;
                          },
                          style: Theme.of(context).textTheme.displaySmall,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintStyle: Theme.of(context).textTheme.displaySmall,
                            hintText: 'Password',
                          ),
                          controller: userPass,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      width: size.width / 1.1,
                      height: 70,
                      decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.onPrimary,
                          borderRadius: BorderRadius.circular(15)),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          obscureText: true,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter Password to confirm';
                            }
                            return null;
                          },
                          style: Theme.of(context).textTheme.displaySmall,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintStyle: Theme.of(context).textTheme.displaySmall,
                            hintText: 'Confirm Password',
                          ),
                          controller: confirmPass,
                        ),
                      ),
                    ),
                    SpaceVH(height: 80.0),
                    Mainbutton(
                      onTap: () async {
                        if (_formKey.currentState!.validate()) {
                          await SignUpUser(context);
                        } else {
                          showSnackBar(context, "Invalid Form Submission");
                        }
                      },
                      text: 'Sign Up',
                      btnColor: blueButton,
                    ),
                  ],
                ),
              ),
              SpaceVH(height: 20.0),
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: RichText(
                  text: TextSpan(children: [
                    TextSpan(
                      text: 'Have an account? ',
                      style: Theme.of(context).textTheme.displaySmall,
                    ),
                    TextSpan(
                      text: ' Sign In',
                      style: headlineDot.copyWith(
                        fontSize: 14.0,
                      ),
                    ),
                  ]),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Future<void> SignUpUser(BuildContext context) async {
    try {
      if (userPass.text == confirmPass.text) {
        final auth = await MunallyAuth.SignUp(userEmail.text, userPass.text);
        if (auth != null) {
          Users user = Users(
            email: userEmail.text,
            name: userName.text,
            password: userPass.text,
            phone: userPh.text,
          );
          final data = await UserServices.insert_user(user);
          if (data == true) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => HomeScreen(),
              ),
            );
            SnackBar(content: Text("registration submited"));
          }
        } else {
          showSnackBar(context, "acc already exist");
          logger.wtf("acc already exist");
        }
      } else {
        showSnackBar(context, "Passwords does not match");
      }
    } catch (e) {
      logger.wtf("Err on signupPage :$e");
    }
  }
}
