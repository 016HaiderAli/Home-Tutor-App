// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import '../../common_widgets/main_button.dart';
import '../../constants/demo.dart';
import '../../utils/colors.dart';
import '../../utils/space.dart';
import '../../utils/text_style.dart';
import 'login/login_page.dart';

class WelcomePage extends StatefulWidget {
  WelcomePage({Key? key}) : super(key: key);

  @override
  _WelcomePageState createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    final size = MediaQuery.of(context).size;
    return Scaffold(
      // backgroundColor: white,
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Stack(
          children: [
            Container(
              height: height / 1,
              // height: height,
              color: blackBG,
              child: Lottie.network(
                "https://assets1.lottiefiles.com/packages/lf20_ggt4iszh.json",
                fit: BoxFit.fill,
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                height: height / 1,
                width: double.infinity,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: gradient,
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    RichText(
                      // ignore: prefer_const_literals_to_create_immutables
                      text: TextSpan(children: [
                        TextSpan(
                          text: 'Online Tution',
                          style: headline1(size.width),
                        ),
                        TextSpan(
                          text: '.',
                          style: headlineDot,
                        ),
                      ]),
                    ),
                    SpaceVH(height: 20.0),
                    Text(
                      splashText,
                      textAlign: TextAlign.center,
                      style: headline2(
                        size.width,
                      ),
                    ),
                    Mainbutton(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (builder) => LoginPage()));
                      },
                      btnColor: blueButton,
                      text: 'Get Started',
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
