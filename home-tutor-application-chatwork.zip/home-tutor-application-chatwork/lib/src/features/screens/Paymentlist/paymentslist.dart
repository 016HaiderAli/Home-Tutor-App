import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/features/screens/Paymentlist/approvepaymentlist.dart';
import 'package:home_tutor_application/src/features/screens/Paymentlist/pendingpaymentlist.dart';

import '../../../common_widgets/MyAppbar.dart';

class Paymentlist extends StatefulWidget {
  const Paymentlist({super.key});

  @override
  State<Paymentlist> createState() => _PaymentlistState();
}

class _PaymentlistState extends State<Paymentlist> {
  @override
  Widget build(BuildContext context) {
    var screensize = MediaQuery.of(context).size;
    return DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: Size(screensize.width, 70),
            child: const MyAppBar(),
          ),
          body: Column(children: [
            Container(
              color: Color.fromARGB(0, 215, 236, 246),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(children: [
                  InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Icon(
                      Icons.arrow_back,
                      color: Theme.of(context).colorScheme.onPrimaryContainer,
                      size: screensize.width / 13,
                    ),
                  ),
                  Text(
                    "View payments",
                    style: TextStyle(
                        fontSize: screensize.width / 27,
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                        fontWeight: FontWeight.bold),
                  ),
                ]),
              ),
            ),
            TabBar(tabs: [
              Tab(
                icon: Icon(Icons.pending_actions),
                text: "Sent Payments",
              ),
              Tab(
                icon: Icon(Icons.done_all_rounded),
                text: "Recived Payments",
              )
            ]),
            Expanded(
              child: TabBarView(
                  children: [pendingpaymentlist(), approvepaymentlist()]),
            )
          ]),
        ));
  }
}
