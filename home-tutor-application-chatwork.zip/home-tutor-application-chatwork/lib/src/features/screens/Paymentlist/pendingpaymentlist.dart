import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/material.dart';

import '../../../common_widgets/paymentbox.dart';

class pendingpaymentlist extends StatefulWidget {
  const pendingpaymentlist({super.key});

  @override
  State<pendingpaymentlist> createState() => _pendingpaymentlistState();
}

class _pendingpaymentlistState extends State<pendingpaymentlist> {
  @override
  Widget build(BuildContext context) {
    var screensize = MediaQuery.of(context).size;

    var userId = FirebaseAuth.instance.currentUser!.uid;
    final Dataref = FirebaseDatabase.instance.ref('Payments');
    final Data = Dataref.orderByChild("PaymentSenderId").equalTo(userId);
    return Column(
      children: [
        SizedBox(
          height: 20,
        ),
        Expanded(
          child: FirebaseAnimatedList(
              query: Data,
              itemBuilder: ((context, snapshot, animation, index) {
                return paymentBox(
                  PaymentId: snapshot.child('Id').value.toString(),
                  Name: snapshot.child('ReciverName').value.toString(),
                  PaidAmount: snapshot.child('PaidAmount').value.toString(),
                  image: snapshot.child('paymentImage').value.toString(),
                  Status: snapshot.child('paymentStatus').value.toString(),
                  showApproval: false,
                );
              })),
        ),
      ],
    );
  }
}
