import 'dart:async';

import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/features/screens/welcome_screen.dart';
import 'package:home_tutor_application/src/utils/colors.dart';
import 'package:lottie/lottie.dart';

class splashScreen extends StatefulWidget {
  const splashScreen({super.key});

  @override
  State<splashScreen> createState() => _splashScreenState();
}

class _splashScreenState extends State<splashScreen> {
  void initState() {
    super.initState();
    Timer(
        Duration(seconds: 4),
        () => Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
              builder: (context) {
                return WelcomePage();
              },
            ), (Route<dynamic> route) => false));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [
        Container(
          width: double.infinity,
          child: Lottie.network(
              "https://assets3.lottiefiles.com/packages/lf20_59uSTvmAp0.json"),
        ),
      ]),
    );
  }
}
