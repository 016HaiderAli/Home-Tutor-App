// ignore_for_file: prefer_const_constructors

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/common_widgets/ChatHead.dart';
import 'package:home_tutor_application/src/common_widgets/FeedBox.dart';
import 'package:home_tutor_application/src/common_widgets/MyAppbar.dart';
import 'package:home_tutor_application/src/features/controller/services/PostService.dart';
import 'package:home_tutor_application/src/features/controller/services/user_services.dart';
import 'package:home_tutor_application/src/features/model/PostModel.dart';
import 'package:home_tutor_application/src/initialization/local_notification.dart';
import 'package:home_tutor_application/src/utils/colors.dart';
import 'package:home_tutor_application/src/utils/logger.dart';
import 'package:home_tutor_application/src/utils/show_snack_bar.dart';
import 'package:home_tutor_application/src/utils/text_style.dart';
import 'dart:convert';
import '../../model/users_model.dart';
import 'package:http/http.dart' as http;

var size, height, width;

class Chatlisting extends StatefulWidget {
  const Chatlisting({Key? key}) : super(key: key);

  @override
  State<Chatlisting> createState() => _ChatlistingState();
}

class _ChatlistingState extends State<Chatlisting> {
  final Search = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  String? name = ''; //
  String? email = ''; //
  String? photo = ''; //
  String? Phonenumber = ''; //
  String? DisplayPicture;
  String? userId;
  String? gname = '';
  String? gemail = '';
  String? gphoto = '';
  late Future<Users> Data;
  bool _is_loading = false;
  var data;
  @override
  void initState() {
    super.initState();
    // getGoogleSignInData();
    getData();
    FirebaseMessaging.instance.getInitialMessage();
    FirebaseMessaging.onMessage.listen((event) {
      LocalNotificationService.display(event);
    });
    FirebaseMessaging.instance.subscribeToTopic('subscription');
  }

  sendNotification(String title) async {
    final data = {
      'click_action': 'FLUTTER_NOTIFICATION_CLICK',
      'id': '1',
      'status': 'done',
      'message': "hey man",
    };

    try {
      http.Response response = await http.post(
        Uri.parse('https://fcm.googleapis.com/fcm/send'),
        headers: <String, String>{
          'Content-Type': 'application/json',
          'Authorization':
              'key=AAAAUJQfhR8:APA91bEEAqv1ZpLLsGWf_tf4fKGw2J1_DEKsxKEYj7UkuqtdRYMFAQ5FxH9s8gnJKXowm7IsQw05PQmacuFflhXdyuOub36Ji2pLOid9VrUSDLbnpyPrVpN-DpCWhSrEjm0h6UJxAVtL'
        },
        body: jsonEncode(
          <String, dynamic>{
            'notification': <String, dynamic>{
              'title': title,
              'body': 'You are followed by someone'
            },
            'priority': 'high',
            'data': data,
            'to': '/topics/subscription'
          },
        ),
      );

      if (response.statusCode == 200) {
        logger.i("Yeh notificatin is sended");
        logger.i("Yeh notificatin is sended");
      } else {
        logger.wtf("error");
        logger.e(response.statusCode);
      }
    } catch (e) {
      logger.e(e);
    }
  }

  Future<Users?> getData() async {
    data = await UserServices.getManuallData();

    if (data != null) {
      if (mounted) {
        setState(() {
          DisplayPicture = data.ProfilePicture;
          name = data.name;
          email = data.email;
          userId = data.uid;
          Phonenumber = data.phone;
        });
      }
    }
    return data;
  }

  @override
  Widget build(BuildContext context) {
    var screensize = MediaQuery.of(context).size;
    size = MediaQuery.of(context).size;
    height = size.height;
    width = size.width;
    var authId = FirebaseAuth.instance.currentUser!.uid;
    final Dataref = FirebaseDatabase.instance
        .ref('ChatConnectiion')
        .orderByChild("CreateDate");

    return data == null
        ? Scaffold(
            body: Center(
              child: Text(
                "Loading...",
                style: Theme.of(context).textTheme.bodyLarge,
              ),
            ),
          )
        : Scaffold(
            // backgroundColor: blackBG,
            appBar: PreferredSize(
              preferredSize: Size(screensize.width, 70),
              child: const MyAppBar(),
            ),
            body: Column(
              children: [
                SizedBox(
                  height: 20,
                ),
                Text("Conversations",
                    style: Theme.of(context).textTheme.bodyLarge),
                Container(
                  width: size.width / 1.1,
                  height: 70,
                  decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.onPrimary,
                      borderRadius: BorderRadius.circular(15)),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextFormField(
                      cursorColor:
                          Theme.of(context).colorScheme.onPrimaryContainer,
                      style: TextStyle(
                          color:
                              Theme.of(context).colorScheme.onPrimaryContainer,
                          fontSize: 18),
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hintStyle: Theme.of(context).textTheme.displaySmall,
                        hintText: 'Search name ',
                      ),
                      controller: Search,
                      onChanged: (value) {
                        setState(() {});
                      },
                    ),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Expanded(
                  child: FirebaseAnimatedList(
                      query: Dataref,
                      itemBuilder: ((context, snapshot, animation, index) {
                        var Name =
                            snapshot.child('chatwithUserName').value.toString();
                        var currentUseridChat = snapshot
                            .child('currentUseridChat')
                            .value
                            .toString();
                        var chatwithUserId =
                            snapshot.child('chatwithUserId').value.toString();
                        if (Name.toLowerCase()
                                .contains(Search.text.toLowerCase()) &&
                            (currentUseridChat == authId ||
                                chatwithUserId == authId)) {
                          return ChatHead(
                            ChatId: snapshot.child('Id').value.toString(),
                            image: snapshot
                                .child('chatwithUserProfilePicture')
                                .value
                                .toString(),
                            Name: snapshot
                                .child('chatwithUserName')
                                .value
                                .toString(),
                            userId: snapshot
                                .child('chatwithUserId')
                                .value
                                .toString(),
                          );
                        } else {
                          return Container();
                        }
                      })),
                ),
              ],
            ),
          );
  }
}
