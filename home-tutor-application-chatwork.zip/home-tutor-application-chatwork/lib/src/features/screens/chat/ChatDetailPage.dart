// ignore_for_file: prefer_const_constructors, sort_child_properties_last

import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/common_widgets/FeedBox.dart';
import 'package:home_tutor_application/src/features/controller/services/chatServices.dart';
import 'package:home_tutor_application/src/features/controller/services/user_services.dart';
import 'package:home_tutor_application/src/features/model/ChatConnectionModel.dart';
import 'package:home_tutor_application/src/features/model/ChatModel.dart';
import 'package:home_tutor_application/src/features/screens/Home/homeScreen.dart';
import 'package:home_tutor_application/src/utils/logger.dart';
import 'package:home_tutor_application/src/utils/show_snack_bar.dart';
import 'package:uuid/uuid.dart';

import '../../../common_widgets/messagebox.dart';

final _formKey = GlobalKey<FormState>();

class ChatDetailPage extends StatefulWidget {
  final String reciverId;
  final String userName;
  final String DisplayPicture;
  final String Chatid;
  ChatDetailPage(
      {required this.reciverId,
      required this.userName,
      required this.DisplayPicture,
      required this.Chatid});
  @override
  _ChatDetailPageState createState() => _ChatDetailPageState();
}

class _ChatDetailPageState extends State<ChatDetailPage> {
  TextEditingController writeMess = TextEditingController();
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var screensize = MediaQuery.of(context).size;
    var size = MediaQuery.of(context).size;
    var height = size.height;
    var width = size.width;
    var currentUserId = FirebaseAuth.instance.currentUser!.uid;
    final Dataref = FirebaseDatabase.instance
        .ref('chatMessages')
        // .orderByChild('ReciverId')
        // .startAt(widget.reciverId)
        // .endAt(widget.reciverId)
        // .orderByChild('SenderId')
        // .startAt(currentUserId)
        // .endAt(currentUserId)
        .orderByChild("CreateDate");

    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        automaticallyImplyLeading: false,
        backgroundColor: Theme.of(context).colorScheme.primary,
        flexibleSpace: SafeArea(
          child: Container(
            padding: EdgeInsets.only(right: 16),
            child: Row(
              children: <Widget>[
                IconButton(
                  onPressed: () {
                    // Navigator.pop(context);
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => HomeScreen(),
                      ),
                    );
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //     builder: (context) => HomeScreen(),
                    //   ),
                    // );
                  },
                  icon: Icon(
                    Icons.arrow_back,
                    color: Theme.of(context).colorScheme.onPrimaryContainer,
                  ),
                ),
                SizedBox(
                  width: 2,
                ),
                CircleAvatar(
                  backgroundImage: NetworkImage(widget.DisplayPicture),
                  maxRadius: 20,
                ),
                SizedBox(
                  width: 12,
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        widget.userName,
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                      SizedBox(
                        height: 6,
                      ),
                      // Text(
                      //   "Online",
                      //   style: TextStyle(
                      //       color: Colors.grey.shade600, fontSize: 13),
                      // ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          SizedBox(
            height: 20,
          ),
          Expanded(
            child: FirebaseAnimatedList(
                query: Dataref,
                itemBuilder: ((context, snapshot, animation, index) {
                  final chatid = snapshot.child('ChatId').value.toString();
                  if (chatid.contains(widget.Chatid)) {
                    return messegeBox(
                        name: snapshot.child('SenderName').value.toString(),
                        contentText:
                            snapshot.child('message').value.toString());
                  } else {
                    return Container();
                  }
                })),
          ),
          Align(
            alignment: Alignment.bottomLeft,
            child: Container(
              padding: EdgeInsets.only(left: 10, bottom: 10, top: 10),
              height: 60,
              width: double.infinity,
              color: Colors.white,
              child: Row(
                children: <Widget>[
                  SizedBox(
                    width: 15,
                  ),
                  Expanded(
                    child: Form(
                      key: _formKey,
                      child: TextFormField(
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please write something..';
                          }
                          return null;
                        },
                        style: TextStyle(color: Colors.black),
                        controller: writeMess,
                        decoration: InputDecoration(
                            hintText: "Write message...",
                            hintStyle: TextStyle(color: Colors.black54),
                            border: InputBorder.none),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 15,
                  ),
                  FloatingActionButton(
                    onPressed: () async {
                      if (_formKey.currentState!.validate()) {
                        bool flag = await sendMessages();
                        if (flag == true) {
                          writeMess.clear();
                        } else {
                          showSnackBar(context, "message sending error");
                        }
                      }
                    },
                    child: Icon(
                      Icons.send,
                      color: Colors.white,
                      size: 18,
                    ),
                    backgroundColor: Theme.of(context).colorScheme.primary,
                    elevation: 0,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  sendMessages() async {
    try {
      var CreationDate = DateTime.now().microsecondsSinceEpoch;
      
      // var s = DateTime.fromMillisecondsSinceEpoch(CreationDate);
      final currentUserData = await UserServices.getManuallData();

      ChatModel chatObj = ChatModel(
          id: "1", //---ignore this
          ChatId: widget.Chatid,
          ReciverId: widget.reciverId,
          SenderName: currentUserData?.name,
          message: writeMess.text,
          CreationDate: CreationDate);

      bool flag = await chatServices.SendMessage(chatObj);
      return flag;
    } catch (e) {
      print("error is ---${e}");
      return false;
    }
  }
}
