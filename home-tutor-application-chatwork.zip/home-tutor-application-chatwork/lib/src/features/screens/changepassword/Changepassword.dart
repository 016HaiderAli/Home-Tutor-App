// ignore_for_file: use_build_context_synchronously, prefer_const_constructors, non_constant_identifier_names

import 'package:flutter/material.dart';

import 'package:home_tutor_application/src/features/controller/services/user_services.dart';

import 'package:home_tutor_application/src/features/model/users_model.dart';
import 'package:home_tutor_application/src/features/screens/Home/homeScreen.dart';

import 'package:home_tutor_application/src/utils/show_snack_bar.dart';
import '../../../common_widgets/main_button.dart';
import '../../../utils/colors.dart';

import '../../../utils/space.dart';



class ChangePassword extends StatefulWidget {
  const ChangePassword({Key? key}) : super(key: key);

  @override
  _ChangePasswordState createState() => _ChangePasswordState();
}

class _ChangePasswordState extends State<ChangePassword> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  TextEditingController currentPassword = TextEditingController();
  TextEditingController NewPassword = TextEditingController();
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      // backgroundColor: blackBG,
      body: Padding(
        padding: EdgeInsets.only(top: 50.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SpaceVH(height: 50.0),
              Text(
                'change password',
                // style: headline1(size.width),
                style: Theme.of(context).textTheme.displayMedium,
              ),
              
              SpaceVH(height: 60.0),
              Form(
                key: _formKey,
                child: Column(
                  children: [
                    Container(
                      width: size.width / 1.1,
                      height: 70,
                      decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.onPrimary,
                          borderRadius: BorderRadius.circular(15)),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          cursorColor:
                              Theme.of(context).colorScheme.onPrimaryContainer,
                          style: Theme.of(context).textTheme.displaySmall,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintStyle: Theme.of(context).textTheme.displaySmall,
                            hintText: 'Current Password',
                            
                          ),
                          controller: currentPassword,
                            validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter Current Password';
                            }
                            return null;
                          },
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      width: size.width / 1.1,
                      height: 70,
                      decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.onPrimary,
                          borderRadius: BorderRadius.circular(15)),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          obscureText: true,
                          // keyboardType: ,
                          cursorColor:
                              Theme.of(context).colorScheme.onPrimaryContainer,
                          style: TextStyle(color: Colors.white, fontSize: 18),
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintStyle: Theme.of(context).textTheme.displaySmall,
                            hintText: 'New Password',
                          ),
                          controller: NewPassword,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter New Password';
                            }
                            return null;
                          },
                        ),
                      ),
                    ),
                    SpaceVH(height: 100.0),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: Column(
                        children: [
                          //Manuall Login with firebase
                          Mainbutton(
                            onTap: () async {
                              if (_formKey.currentState!.validate()) {
                                if (currentPassword.text == NewPassword.text) {
                                  ChangePassword();
                                } else {
                                  showSnackBar(
                                      context, "Password are not matching");
                                }
                              }
                            },
                            text: 'Set As New Password',
                            btnColor: blueButton,
                          ),
                          SpaceVH(height: 20.0),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  ChangePassword() async {
    final Svc = UserServices();
    Users UserData = Users(
      name: "",
      password: NewPassword.text,
    );
    var flag = await Svc.ChangePassword(UserData);

    if (flag == true) {
      showSnackBar(context, "Password updated successfully");

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) {
            return HomeScreen();
          },
        ),
      );
    } else {
      showSnackBar(context, "Password updating Failed");
    }
  }
}
