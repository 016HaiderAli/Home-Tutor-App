// ignore_for_file: use_build_context_synchronously, prefer_const_constructors, non_constant_identifier_names

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/features/controller/services/munally_auth_services.dart';
import 'package:home_tutor_application/src/features/controller/services/user_services.dart';
import 'package:home_tutor_application/src/features/model/user2_model.dart';
import 'package:home_tutor_application/src/features/screens/Home/homeScreen.dart';
import 'package:home_tutor_application/src/features/screens/dashborad/Dashboard.dart';
import 'package:home_tutor_application/src/utils/show_snack_bar.dart';
import '../../../common_widgets/main_button.dart';
import '../../../utils/colors.dart';
import '../../../utils/logger.dart';
import '../../../utils/space.dart';
import '../../../utils/text_style.dart';
import '../../controller/services/google_auth_service.dart';

import '../signup/sign_up.dart';
import 'ResetPassword.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  TextEditingController userName = TextEditingController();
  TextEditingController userPass = TextEditingController();
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      // backgroundColor: blackBG,
      body: Padding(
        padding: EdgeInsets.only(top: 50.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SpaceVH(height: 50.0),
              Text(
                'Welcome Back!',
                // style: headline1(size.width),
                style: Theme.of(context).textTheme.displayMedium,
              ),
              SpaceVH(height: 10.0),
              Text(
                'Please sign in to your account',
                // style: headline3,
                style: Theme.of(context).textTheme.displaySmall,
              ),
              SpaceVH(height: 60.0),
              Form(
                key: _formKey,
                child: Column(
                  children: [
                    Container(
                      width: size.width / 1.1,
                      height: 70,
                      decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.onPrimary,
                          borderRadius: BorderRadius.circular(15)),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          cursorColor:
                              Theme.of(context).colorScheme.onPrimaryContainer,
                          style: Theme.of(context).textTheme.displaySmall,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintStyle: Theme.of(context).textTheme.displaySmall,
                            hintText: 'Email',
                          ),
                          controller: userName,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter Email';
                            }
                            return null;
                          },
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      width: size.width / 1.1,
                      height: 70,
                      decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.onPrimary,
                          borderRadius: BorderRadius.circular(15)),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          obscureText: true,
                          // keyboardType: ,
                          cursorColor:
                              Theme.of(context).colorScheme.onPrimaryContainer,
                          style: TextStyle(color: Colors.white, fontSize: 18),
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintStyle: Theme.of(context).textTheme.displaySmall,
                            hintText: 'Password',
                          ),
                          controller: userPass,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter Password';
                            }
                            return null;
                          },
                        ),
                      ),
                    ),
                    TextButton(
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) => ResetScreen(),
                            ),
                          );
                        },
                        child: Align(
                          alignment: Alignment.topRight,
                          child: Text(
                            "Forgot Account",
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        )),
                    SpaceVH(height: 10.0),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Padding(
                        padding: EdgeInsets.only(right: 20.0),
                        child: TextButton(
                          onPressed: () {},
                          child: Text(
                            // 'Forgot Password?',
                            '',
                            style: headline3,
                          ),
                        ),
                      ),
                    ),
                    SpaceVH(height: 100.0),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: Column(
                        children: [
                          //Manuall Login with firebase
                          Mainbutton(
                            onTap: () async {
                              if (_formKey.currentState!.validate()) {
                                await ManuallySignLocal(context);
                              }
                            },
                            text: 'Sign in',
                            btnColor: blueButton,
                          ),
                          SpaceVH(height: 20.0),
                          //sign in with goolge

                          Mainbutton(
                            onTap: () async {
                              await GoogleSign(context);
                            },
                            text: 'Sign in with google',
                            image: 'google.png',
                            btnColor: Theme.of(context).colorScheme.background,
                            txtColor: blackBG,
                          ),
                          SpaceVH(height: 20.0),
                          TextButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (_) => SignUpPage()),
                              );
                            },
                            child: RichText(
                              text: TextSpan(children: [
                                TextSpan(
                                  text: 'Have an account? ',
                                  style:
                                      Theme.of(context).textTheme.displaySmall,
                                ),
                                TextSpan(
                                  text: ' Sign Up',
                                  style: headlineDot.copyWith(
                                    fontSize: 14.0,
                                  ),
                                ),
                              ]),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<UserCredential?> GoogleSign(BuildContext context) async {
    try {
      final auth = await AuthServices.signInWithGoogle();
      // User2 data;
      if (auth != null) {
        var a = FirebaseAuth.instance.currentUser;
        final s = await UserServices.getUserById(a!.uid);

        if (s == null) {
          User2 user = User2(
            name: a.displayName,
            phone: "+92XXXXXXXXX",
            email: a.email,
            uid: a.uid,
            profilePicture: a.photoURL.toString(),
            rating: '0',
            password: '123456',
          );
          final data = await AuthServices.insert_user(user);
          if (data == true) {
            logger.wtf("google data submited");
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => HomeScreen(),
              ),
            );
          }
        } else {
          showSnackBar(context, "Welcome back ${auth.displayName}");
          logger.wtf("already have an data");
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => HomeScreen(),
            ),
          );
        }
      }
      // logger.wtf("Succefull login with google (login screen) ");
    } catch (e) {
      logger.wtf("login screen err: $e");
    }
  }

  Future<User?> ManuallySignLocal(BuildContext context) async {
    UserCredential? collectData;
    try {
      if (userName.text == '' || userPass.text == '') {
        logger.wtf("err on loginscreen empty fields no requird line 195");
        return null;
      }
      collectData = await MunallyAuth.Signin(userName.text, userPass.text);
      if (collectData != null) {
        Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
              builder: (_) => HomeScreen(),
            ),
            (route) => false);
      } else {
        showSnackBar(context, "Invalid! Email & Password");
        return null;
      }
    } catch (e) {
      logger.wtf(e);
    }
    return collectData?.user;
  }
}
