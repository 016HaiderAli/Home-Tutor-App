// ignore_for_file: prefer_const_constructors
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/features/screens/chat/ChatDetailPage.dart';
import 'package:home_tutor_application/src/features/screens/chat/ChatslistScreen.dart';
import 'package:home_tutor_application/src/features/screens/dashborad/Dashboard.dart';
import 'package:home_tutor_application/src/utils/colors.dart';
import '../Adslisting/Adslisting.dart';

class HomeScreen extends StatefulWidget {
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  var CurrentTab = 0;

  final List<Widget> Screens = [Adslisting()];

  final PageStorageBucket bucket = PageStorageBucket();

  Widget currentScreen = Dashboard();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageStorage(bucket: bucket, child: currentScreen),
      bottomNavigationBar: CurvedNavigationBar(
        backgroundColor: Theme.of(context).colorScheme.onSurface,
        buttonBackgroundColor: blueButton,
        color: Theme.of(context).colorScheme.primary,
        onTap: (index) {
          if (index == 0) {
            setState(() {
              currentScreen = Dashboard();
            });
          }
          if (index == 1) {
            setState(() {
              currentScreen = Adslisting();
            });
          }

          if (index == 2) {
            setState(() {
              currentScreen = Chatlisting();
            });
          }
        },
        // ignore: prefer_const_literals_to_create_immutables
        items: <Widget>[
          Icon(
            Icons.dashboard,
            size: 30,
            color: Colors.white,
          ),
          Icon(
            Icons.list,
            size: 30,
            color: Colors.white,
          ),
          Icon(
            Icons.message_outlined,
            size: 30,
            color: Colors.white,
          ),
        ],
      ),
    );
  }
}
