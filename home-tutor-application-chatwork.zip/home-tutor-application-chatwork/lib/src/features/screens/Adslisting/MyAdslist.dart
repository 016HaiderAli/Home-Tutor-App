import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/common_widgets/MyAppbar.dart';
import 'package:home_tutor_application/src/common_widgets/myPost.dart';
import 'package:home_tutor_application/src/utils/colors.dart';

var size, height, width;

class MyAdslist extends StatefulWidget {
  const MyAdslist({Key? key}) : super(key: key);

  @override
  State<MyAdslist> createState() => _MyAdslistState();
}

class _MyAdslistState extends State<MyAdslist> {
  var Data;
  bool _is_loading = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var screensize = MediaQuery.of(context).size;
    size = MediaQuery.of(context).size;
    height = size.height;
    width = size.width;
    var userId = FirebaseAuth.instance.currentUser!.uid;
    final Dataref = FirebaseDatabase.instance.ref('Posts');
    final Data = Dataref.orderByChild("userId").equalTo(userId);
    return Scaffold(
      
      appBar: PreferredSize(
        preferredSize: Size(screensize.width, 70),
        child: const MyAppBar(),
      ),
      body: Column(
        children: [
          Container(
            color: Color.fromARGB(0, 215, 236, 246),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Icon(
                    Icons.arrow_back,
                    color: Theme.of(context).colorScheme.onPrimaryContainer,
                    size: screensize.width / 13,
                  ),
                ),
                Text(
                  "My Post",
                  style: TextStyle(
                      fontSize: screensize.width / 27,
                      color: Theme.of(context).colorScheme.onPrimaryContainer,
                      fontWeight: FontWeight.bold),
                ),
              ]),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Expanded(
            child: FirebaseAnimatedList(
                query: Data,
                itemBuilder: ((context, snapshot, animation, index) {
                  return myPost(
                    ProfilePicture:
                        snapshot.child('DisplayPicture').value.toString(),
                    name: snapshot.child('name').value.toString(),
                    contentText: snapshot.child('description').value.toString(),
                    PostId: snapshot.child('PostId').value.toString(),
                  );
                })),
          ),
        ],
      ),
    );
  }
}
