import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/common_widgets/MyAppbar.dart';
import 'package:home_tutor_application/src/common_widgets/myPost.dart';
import 'package:home_tutor_application/src/utils/colors.dart';

import '../../../common_widgets/ApproveTutor.dart';

var size, height, width;

class ApproveTutorlist extends StatefulWidget {
  const ApproveTutorlist({Key? key}) : super(key: key);

  @override
  State<ApproveTutorlist> createState() => _ApproveTutorlistState();
}

class _ApproveTutorlistState extends State<ApproveTutorlist> {
  var Data;
  bool _is_loading = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var screensize = MediaQuery.of(context).size;
    size = MediaQuery.of(context).size;
    height = size.height;
    width = size.width;
    var userId = FirebaseAuth.instance.currentUser!.uid;
    final Dataref = FirebaseDatabase.instance.ref('Tutors');
    final Data = Dataref.orderByChild("ApproveByUserId").equalTo(userId);
    return Scaffold(
      // backgroundColor: blackBG,
      appBar: PreferredSize(
        preferredSize: Size(screensize.width, 70),
        child: const MyAppBar(),
      ),
      body: Column(
        children: [
          Container(
            color: Color.fromARGB(0, 215, 236, 246),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Icon(
                    Icons.arrow_back,
                    color: Theme.of(context).colorScheme.onPrimaryContainer,
                    size: screensize.width / 13,
                  ),
                ),
                Text(
                  "View Approve Tutor",
                  // style: TextStyle(
                  //     fontSize: screensize.width / 27,
                  //     color: Theme.of(context).colorScheme.onSecondary,
                  //     fontWeight: FontWeight.bold),
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ]),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Expanded(
            child: FirebaseAnimatedList(
                query: Data,
                itemBuilder: ((context, snapshot, animation, index) {
                  return ApproveTutor(
                    Id: snapshot.child('TutorId').value.toString(),
                    contentText: '',
                    DisplayPicture:
                        snapshot.child('DisplayPicture').value.toString(),
                    name: snapshot.child('TutorName').value.toString(),
                  );
                })),
          ),
        ],
      ),
    );
  }
}
