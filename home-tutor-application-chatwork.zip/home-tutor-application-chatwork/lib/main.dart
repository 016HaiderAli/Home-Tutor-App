// ignore_for_file: deprecated_member_use, prefer_const_constructors, prefer_const_constructors_in_immutables

import 'package:flutter/material.dart';
import 'package:home_tutor_application/src/features/controller/services/google_auth_service.dart';
import 'package:home_tutor_application/src/initialization/firebaseDB.dart';

void main() async {
  await FirebaseDB.init();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    // var size = MediaQuery.of(context).size;
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.orange,
        colorScheme: ColorScheme(
          primaryContainer: Colors.white,
          onPrimaryContainer: Colors.black,
          brightness: Brightness.light,
          primary: Colors.orange,
          onPrimary: Color.fromARGB(255, 233, 229, 229),
          secondary: Colors.orange.shade100,
          onSecondary: Colors.black,
          error: Colors.red,
          onError: Colors.redAccent,
          background: Color.fromARGB(255, 233, 229, 229),
          onBackground: Colors.white,
          surface: Color.fromARGB(179, 218, 208, 208),
          onSurface: Colors.white,
        ),
        backgroundColor: Colors.deepOrange[100],
        textTheme: TextTheme(
          bodyMedium: TextStyle(
            color: Colors.black,
          ),
          bodyLarge: TextStyle(
            color: Colors.black,
            fontSize: 40,
          ),
          displayLarge: TextStyle(
            color: Colors.black,
            fontSize: 20,
            fontWeight: FontWeight.w900,
          ),
          displayMedium: TextStyle(
            color: Color.fromARGB(255, 212, 138, 11),
            fontSize: 40,
          ),
          displaySmall: TextStyle(
            color: Colors.black,
            fontSize: 15,
          ),
        ),
        appBarTheme: AppBarTheme(
          color: Color.fromARGB(255, 14, 41, 55),
        ),
      ),
      // darkTheme mode
      darkTheme: ThemeData(
        scaffoldBackgroundColor: Color(0xFF181A20),
        colorScheme: ColorScheme(
          primaryContainer: Color(0xFF181A20),
          onPrimaryContainer: Colors.white,
          brightness: Brightness.dark,
          primary: Color.fromARGB(255, 14, 41, 55),
          onPrimary: Color(0xFF262A34),
          secondary: Colors.deepOrangeAccent,
          onSecondary: Colors.black,
          error: Colors.red,
          onError: Colors.redAccent,
          background: Colors.white,
          onBackground: Colors.white,
          surface: Colors.white70,
          onSurface: Color(0xFF181A20),
        ),
        textTheme: TextTheme(
            bodyMedium: TextStyle(
              color: Colors.white,
            ),
            bodyLarge: TextStyle(
              color: Colors.white,
              fontSize: 40,
            ),
            displayLarge: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.w900,
            ),
            displayMedium: TextStyle(
              color: Color.fromARGB(255, 212, 138, 11),
              fontSize: 40,
            ),
            displaySmall: TextStyle(
              color: Colors.grey,
              fontSize: 15,
            )),
        appBarTheme: AppBarTheme(
          color: Color.fromARGB(255, 14, 41, 55),
        ),
      ),
      themeMode: ThemeMode.system,
      home: AuthServices.handleAuthState(),
    );
  }
}
