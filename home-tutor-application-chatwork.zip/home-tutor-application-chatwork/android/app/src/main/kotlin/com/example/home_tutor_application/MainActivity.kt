package com.example.home_tutor_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
